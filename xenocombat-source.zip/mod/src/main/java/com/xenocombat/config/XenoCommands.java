package com.xenocombat.config;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * /xenocombat list | get <option> | set <option> <value>   (operators only)
 * Lets server owners tune combat live on a dedicated server (where the config screen only edits the client's own
 * file). Changes are validated against the same ranges as the config file and written back to it.
 * Option names are the dotted paths used in xenocombat-common.toml, e.g. vanish.cooldownTicks or npc.difficulty.
 */
public final class XenoCommands {

    @SubscribeEvent
    public void onRegister(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("xenocombat")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("list").executes(this::list))
                .then(Commands.literal("get")
                        .then(Commands.argument("option", StringArgumentType.word()).executes(this::get)))
                .then(Commands.literal("set")
                        .then(Commands.argument("option", StringArgumentType.word())
                                .then(Commands.argument("value", StringArgumentType.word()).executes(this::set)))));
    }

    private int list(CommandContext<CommandSourceStack> ctx) {
        StringBuilder sb = new StringBuilder("Xeno Combat options (use /xenocombat get|set <option>):");
        for (ForgeConfigSpec.ConfigValue<?> cv : ConfigAccess.values(XenoConfig.COMMON_SPEC)) {
            sb.append("\n  ").append(ConfigAccess.path(cv)).append(" = ").append(cv.get());
        }
        ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
        return 1;
    }

    private int get(CommandContext<CommandSourceStack> ctx) {
        String name = StringArgumentType.getString(ctx, "option");
        ForgeConfigSpec.ConfigValue<?> cv = ConfigAccess.find(XenoConfig.COMMON_SPEC, name);
        if (cv == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown option '" + name + "'. Try /xenocombat list"));
            return 0;
        }
        String comment = ConfigAccess.comment(XenoConfig.COMMON_SPEC, cv);
        ctx.getSource().sendSuccess(() -> Component.literal(ConfigAccess.path(cv) + " = " + cv.get()
                + (comment.isEmpty() ? "" : "  (" + comment.trim() + ")")), false);
        return 1;
    }

    private int set(CommandContext<CommandSourceStack> ctx) {
        String name = StringArgumentType.getString(ctx, "option");
        String value = StringArgumentType.getString(ctx, "value");
        ForgeConfigSpec.ConfigValue<?> cv = ConfigAccess.find(XenoConfig.COMMON_SPEC, name);
        if (cv == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown option '" + name + "'. Try /xenocombat list"));
            return 0;
        }
        String error = ConfigAccess.apply(XenoConfig.COMMON_SPEC, cv, value);
        if (error != null) {
            ctx.getSource().sendFailure(Component.literal("Cannot set " + ConfigAccess.path(cv) + ": " + error));
            return 0;
        }
        XenoConfig.COMMON_SPEC.save();
        ctx.getSource().sendSuccess(() -> Component.literal("Set " + ConfigAccess.path(cv) + " = " + cv.get()), true);
        return 1;
    }
}
