package com.xenocombat.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * All tunables. COMMON config (config/xenocombat-common.toml) is read by both client and server;
 * on a dedicated server the server's file governs combat. CLIENT config holds camera/visual options only.
 * Tick values: 20 ticks = 1 second.
 */
public final class XenoConfig {
    public enum Difficulty { EASY, NORMAL, HARD }

    public static final ForgeConfigSpec COMMON_SPEC;
    public static final ForgeConfigSpec CLIENT_SPEC;

    // ---- feature toggles
    public static final ForgeConfigSpec.BooleanValue ENABLE_LOCK_ON, ENABLE_FLIGHT, ENABLE_VANISH, ENABLE_DODGE,
            ENABLE_PARRY, ENABLE_LUNGE, ENABLE_AERIAL, ENABLE_NPC_AI;

    // ---- combat
    public static final ForgeConfigSpec.DoubleValue M1_DAMAGE, M1_REACH, FINISHER_MULTIPLIER, LAUNCH_HORIZONTAL, LAUNCH_VERTICAL;
    public static final ForgeConfigSpec.IntValue COMBO_WINDOW_TICKS, M1_COOLDOWN_TICKS, HITSTUN_TICKS, FINISHER_STUN_TICKS, HITSTUN_IMMUNITY_TICKS;
    public static final ForgeConfigSpec.DoubleValue LUNGE_RANGE, LUNGE_SPEED;

    // ---- defense
    public static final ForgeConfigSpec.DoubleValue GUARD_DAMAGE_MULTIPLIER, GUARD_ARC_DEGREES, DODGE_DISTANCE;
    public static final ForgeConfigSpec.IntValue PARRY_WINDOW_TICKS, PARRY_PUNISH_TICKS, DODGE_COOLDOWN_TICKS, DODGE_INVULN_TICKS, GUARD_BREAK_COOLDOWN_TICKS;

    // ---- vanish
    public static final ForgeConfigSpec.IntValue VANISH_COOLDOWN_TICKS, VANISH_WINDOW_TICKS;
    public static final ForgeConfigSpec.DoubleValue VANISH_MAX_DISTANCE, VANISH_BEHIND_DISTANCE;

    // ---- flight
    public static final ForgeConfigSpec.DoubleValue FLIGHT_SPEED, FLIGHT_BOOST_SPEED, FLIGHT_ACCELERATION, FLIGHT_TURN_LERP;

    // ---- targeting
    public static final ForgeConfigSpec.DoubleValue LOCK_ON_RANGE;
    public static final ForgeConfigSpec.BooleanValue LOCK_ON_LOS, TARGET_HOSTILE, TARGET_PASSIVE, TARGET_PLAYERS, TARGET_OTHER;

    // ---- AI
    public static final ForgeConfigSpec.DoubleValue NPC_HEALTH, NPC_DAMAGE, NPC_ARMOR, NPC_SPEED, NPC_FLIGHT_SPEED,
            NPC_COMBAT_RANGE, NPC_DETECTION_RANGE, NPC_PURSUIT_RANGE, NPC_PARRY_SCALE, NPC_DODGE_SCALE, NPC_VANISH_SCALE;
    public static final ForgeConfigSpec.EnumValue<Difficulty> NPC_DIFFICULTY;
    public static final ForgeConfigSpec.IntValue NPC_REACTION_OVERRIDE_TICKS;
    public static final ForgeConfigSpec.BooleanValue NPC_FLIGHT_ENABLED, NPC_SWITCH_TARGETS, NPC_FIGHT_OTHER_NPCS,
            NPC_ATTACK_OTHER_MOBS, NPC_NATURAL_SPAWN;

    // ---- client / camera
    public static final ForgeConfigSpec.BooleanValue CAM_LOCK_ON, CAM_FORCE_THIRD_PERSON, ENABLE_COMBAT_CAMERA;
    public static final ForgeConfigSpec.DoubleValue CAM_SMOOTHING;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Feature toggles").push("features");
        ENABLE_LOCK_ON = b.define("lockOn", true);
        ENABLE_FLIGHT = b.define("flight", true);
        ENABLE_VANISH = b.define("zVanish", true);
        ENABLE_DODGE = b.define("dodge", true);
        ENABLE_PARRY = b.define("perfectParry", true);
        ENABLE_LUNGE = b.define("lunge", true);
        ENABLE_AERIAL = b.comment("Allows M1/guard/parry/dodge/vanish while flying").define("aerialCombat", true);
        ENABLE_NPC_AI = b.define("npcAi", true);
        b.pop();

        b.comment("M1 combo / hitstun").push("combat");
        M1_DAMAGE = b.comment("Damage of hits 1-4").defineInRange("m1Damage", 5.0, 0.0, 1000.0);
        M1_REACH = b.comment("Melee reach in blocks (center distance to target hitbox)").defineInRange("m1Reach", 3.4, 1.0, 12.0);
        FINISHER_MULTIPLIER = b.comment("Hit 5 damage = m1Damage * this").defineInRange("finisherDamageMultiplier", 1.6, 0.1, 20.0);
        LAUNCH_HORIZONTAL = b.comment("Fifth-hit launch, horizontal velocity").defineInRange("launchHorizontal", 1.1, 0.0, 6.0);
        LAUNCH_VERTICAL = b.comment("Fifth-hit launch, vertical velocity").defineInRange("launchVertical", 0.85, 0.0, 4.0);
        COMBO_WINDOW_TICKS = b.comment("Ticks after a hit in which the next M1 continues the combo").defineInRange("comboWindowTicks", 16, 4, 100);
        M1_COOLDOWN_TICKS = b.comment("Minimum ticks between M1 swings").defineInRange("m1CooldownTicks", 6, 2, 40);
        HITSTUN_TICKS = b.comment("Hitstun applied by hits 1-4 (kept just longer than the M1 cadence so hits connect)").defineInRange("hitstunTicks", 14, 2, 100);
        FINISHER_STUN_TICKS = b.comment("Stun after launch (airborne recovery)").defineInRange("finisherStunTicks", 24, 2, 100);
        HITSTUN_IMMUNITY_TICKS = b.comment("After a launch ends, ticks the victim cannot be hitstunned again (anti stun-lock)").defineInRange("hitstunImmunityTicks", 30, 0, 200);
        LUNGE_RANGE = b.comment("Max distance an M1 will lunge toward the locked target").defineInRange("lungeRange", 9.0, 0.0, 32.0);
        LUNGE_SPEED = b.comment("Blocks per tick during lunge").defineInRange("lungeSpeed", 1.5, 0.2, 4.0);
        b.pop();

        b.comment("Guard / parry / dodge").push("defense");
        GUARD_DAMAGE_MULTIPLIER = b.comment("Damage multiplier while guarding (0 = negate)").defineInRange("guardDamageMultiplier", 0.1, 0.0, 1.0);
        GUARD_ARC_DEGREES = b.comment("Frontal arc covered by guard").defineInRange("guardArcDegrees", 140.0, 30.0, 360.0);
        PARRY_WINDOW_TICKS = b.comment("Guard must have started within this many ticks of the hit for a perfect parry").defineInRange("parryWindowTicks", 6, 1, 20);
        PARRY_PUNISH_TICKS = b.comment("Attacker stun after being parried").defineInRange("parryPunishTicks", 30, 5, 100);
        GUARD_BREAK_COOLDOWN_TICKS = b.comment("After a parry attempt window closes (guard released), ticks before guard can be raised again; stops parry spam").defineInRange("guardReraiseTicks", 10, 0, 60);
        DODGE_DISTANCE = b.comment("Dodge travel distance in blocks").defineInRange("dodgeDistance", 5.0, 1.0, 16.0);
        DODGE_COOLDOWN_TICKS = b.defineInRange("dodgeCooldownTicks", 24, 0, 200);
        DODGE_INVULN_TICKS = b.comment("Ticks of melee-hit immunity during dodge").defineInRange("dodgeInvulnTicks", 8, 0, 40);
        b.pop();

        b.comment("Z-Vanish").push("vanish");
        VANISH_COOLDOWN_TICKS = b.comment("7 seconds = 140 ticks. Enforced server-side.").defineInRange("cooldownTicks", 140, 0, 6000);
        VANISH_WINDOW_TICKS = b.comment("Defensive vanish allowed while hitstunned or within this many ticks of the last hit taken").defineInRange("activationWindowTicks", 20, 0, 100);
        VANISH_MAX_DISTANCE = b.comment("Max range to the pursuit target for offensive vanish").defineInRange("teleportDistance", 28.0, 4.0, 128.0);
        VANISH_BEHIND_DISTANCE = b.comment("Arrival distance behind target").defineInRange("behindDistance", 2.2, 1.0, 6.0);
        b.pop();

        b.comment("Combat flight").push("flight");
        FLIGHT_SPEED = b.defineInRange("speed", 0.55, 0.1, 3.0);
        FLIGHT_BOOST_SPEED = b.defineInRange("boostSpeed", 1.1, 0.1, 5.0);
        FLIGHT_ACCELERATION = b.comment("Fraction of the speed gap closed per tick").defineInRange("acceleration", 0.12, 0.01, 1.0);
        FLIGHT_TURN_LERP = b.comment("How quickly velocity direction follows input (turning)").defineInRange("turning", 0.25, 0.02, 1.0);
        b.pop();

        b.comment("Lock-on / targeting").push("targeting");
        LOCK_ON_RANGE = b.defineInRange("lockOnRange", 24.0, 4.0, 96.0);
        LOCK_ON_LOS = b.define("requireLineOfSight", true);
        TARGET_HOSTILE = b.define("targetHostile", true);
        TARGET_PASSIVE = b.define("targetPassive", true);
        TARGET_PLAYERS = b.define("targetPlayers", true);
        TARGET_OTHER = b.define("targetOtherLiving", true);
        b.pop();

        b.comment("Combat NPC").push("npc");
        NPC_DIFFICULTY = b.defineEnum("difficulty", Difficulty.NORMAL);
        NPC_HEALTH = b.defineInRange("health", 100.0, 1.0, 10000.0);
        NPC_DAMAGE = b.comment("Base damage of the NPC's hits 1-4").defineInRange("damage", 4.0, 0.0, 1000.0);
        NPC_ARMOR = b.defineInRange("defense", 4.0, 0.0, 30.0);
        NPC_SPEED = b.defineInRange("movementSpeed", 0.32, 0.05, 1.5);
        NPC_FLIGHT_SPEED = b.defineInRange("flightSpeed", 0.5, 0.1, 3.0);
        NPC_COMBAT_RANGE = b.comment("Preferred spacing from target").defineInRange("combatRange", 2.8, 1.5, 8.0);
        NPC_DETECTION_RANGE = b.defineInRange("detectionRange", 28.0, 4.0, 96.0);
        NPC_PURSUIT_RANGE = b.comment("Gives up the fight beyond this distance").defineInRange("pursuitRange", 48.0, 8.0, 160.0);
        NPC_REACTION_OVERRIDE_TICKS = b.comment("-1 = use difficulty default").defineInRange("reactionTicksOverride", -1, -1, 40);
        NPC_PARRY_SCALE = b.comment("Multiplier on the difficulty's parry attempt chance").defineInRange("parryChanceScale", 1.0, 0.0, 5.0);
        NPC_DODGE_SCALE = b.defineInRange("dodgeChanceScale", 1.0, 0.0, 5.0);
        NPC_VANISH_SCALE = b.defineInRange("vanishChanceScale", 1.0, 0.0, 5.0);
        NPC_FLIGHT_ENABLED = b.define("flightEnabled", true);
        NPC_SWITCH_TARGETS = b.define("switchTargets", false);
        NPC_FIGHT_OTHER_NPCS = b.comment("Combat NPCs treat each other as valid opponents").define("fightOtherCombatNpcs", false);
        NPC_ATTACK_OTHER_MOBS = b.define("attackUnrelatedMobs", false);
        NPC_NATURAL_SPAWN = b.comment("Reserved: natural spawning is only wired when true").define("naturalSpawning", false);
        b.pop();
        COMMON_SPEC = b.build();

        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        c.comment("Camera").push("camera");
        ENABLE_COMBAT_CAMERA = c.define("enableCombatCamera", true);
        CAM_LOCK_ON = c.comment("Camera turns toward the locked target").define("lockOnCamera", true);
        CAM_SMOOTHING = c.comment("0 = frozen, 1 = instant").defineInRange("lockOnSmoothing", 0.35, 0.02, 1.0);
        CAM_FORCE_THIRD_PERSON = c.comment("Switch to third person while locked on").define("forceThirdPersonOnLock", false);
        c.pop();
        CLIENT_SPEC = c.build();
    }

    private XenoConfig() {}
}
