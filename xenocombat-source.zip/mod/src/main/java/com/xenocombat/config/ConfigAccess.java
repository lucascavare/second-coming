package com.xenocombat.config;

import com.electronwill.nightconfig.core.UnmodifiableConfig;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.List;

/**
 * Generic read/write access to every option in a ForgeConfigSpec, used by both the in-game config screen and the
 * /xenocombat command. Nothing here knows about individual options, so new options appear everywhere automatically.
 */
public final class ConfigAccess {

    /** Every leaf value of the spec, in declaration order. */
    public static List<ForgeConfigSpec.ConfigValue<?>> values(ForgeConfigSpec spec) {
        List<ForgeConfigSpec.ConfigValue<?>> out = new ArrayList<>();
        collect(spec.getValues(), out);
        return out;
    }

    private static void collect(UnmodifiableConfig cfg, List<ForgeConfigSpec.ConfigValue<?>> out) {
        for (Object o : cfg.valueMap().values()) {
            if (o instanceof ForgeConfigSpec.ConfigValue<?> cv) {
                out.add(cv);
            } else if (o instanceof UnmodifiableConfig sub) {
                collect(sub, out);
            }
        }
    }

    public static String path(ForgeConfigSpec.ConfigValue<?> cv) {
        return String.join(".", cv.getPath());
    }

    public static ForgeConfigSpec.ConfigValue<?> find(ForgeConfigSpec spec, String path) {
        for (ForgeConfigSpec.ConfigValue<?> cv : values(spec)) {
            if (path(cv).equalsIgnoreCase(path)) {
                return cv;
            }
        }
        return null;
    }

    public static String comment(ForgeConfigSpec spec, ForgeConfigSpec.ConfigValue<?> cv) {
        Object vs = spec.getSpec().get(cv.getPath());
        if (vs instanceof ForgeConfigSpec.ValueSpec v && v.getComment() != null) {
            return v.getComment();
        }
        return "";
    }

    /**
     * Parse text into the option's own type and validate it against the spec's range. Returns an error message,
     * or null on success (in which case the value has been applied; call spec.save() afterwards).
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String apply(ForgeConfigSpec spec, ForgeConfigSpec.ConfigValue<?> cv, String text) {
        Object current = cv.get();
        Object parsed;
        try {
            if (current instanceof Boolean) {
                if (!text.equalsIgnoreCase("true") && !text.equalsIgnoreCase("false")) {
                    return "expected true or false";
                }
                parsed = Boolean.parseBoolean(text);
            } else if (current instanceof Integer) {
                parsed = Integer.parseInt(text.trim());
            } else if (current instanceof Double) {
                parsed = Double.parseDouble(text.trim());
            } else if (current instanceof Enum<?> e) {
                parsed = Enum.valueOf((Class<? extends Enum>) e.getDeclaringClass(), text.trim().toUpperCase());
            } else {
                parsed = text;
            }
        } catch (IllegalArgumentException ex) {
            return "not a valid " + current.getClass().getSimpleName().toLowerCase();
        }
        Object vs = spec.getSpec().get(cv.getPath());
        if (vs instanceof ForgeConfigSpec.ValueSpec v && !v.test(parsed)) {
            return "out of the allowed range";
        }
        ((ForgeConfigSpec.ConfigValue) cv).set(parsed);
        return null;
    }

    private ConfigAccess() {}
}
