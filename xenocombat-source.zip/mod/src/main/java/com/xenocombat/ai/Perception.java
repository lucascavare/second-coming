package com.xenocombat.ai;

import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.CombatState;
import com.xenocombat.core.StateManager;
import com.xenocombat.core.Targeting;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * What the NPC can actually perceive about its target - and nothing more. It deliberately does NOT read the
 * target's cooldowns, combo counter, input or intentions. Everything below corresponds to something an onlooker
 * could see: where the target is (needs line of sight within detection range, otherwise only the last seen
 * position), whether it is airborne, its guard pose, swinging, being stunned, bursting sideways (dodge), or
 * vanishing in a puff of smoke.
 */
public final class Perception {
    public boolean visible;
    public double dist;               // centre-to-centre
    public double hitDist;            // eye to target hitbox
    public boolean airborne;
    public boolean flying;
    public boolean guarding;
    public boolean stunned;
    public boolean launched;
    public boolean dodging;
    public boolean swungJustNow;      // swing animation started within the last tick or two
    public boolean lunging;
    public boolean facingMe;
    public boolean closingIn;         // moving toward me quickly while near
    public boolean vanishedJustNow;   // seen disappearing (needs line of sight to the point it left from)

    public long lastSeenTick = -10000;
    public Vec3 lastSeenPos = Vec3.ZERO;
    private Vec3 prevPos = Vec3.ZERO;
    private long losTick = -10000;
    private boolean losCache;

    public void reset() {
        visible = false;
        lastSeenTick = -10000;
        losTick = -10000;
    }

    public void update(LivingEntity self, LivingEntity t, long now) {
        dist = self.distanceTo(t);
        hitDist = Targeting.hitboxDistance(self, t);
        if (now - losTick >= 4) { // line-of-sight raycast at most every 4 ticks
            losCache = self.hasLineOfSight(t);
            losTick = now;
        }
        visible = dist <= XenoConfig.NPC_DETECTION_RANGE.get() && losCache;
        if (visible) {
            lastSeenTick = now;
            lastSeenPos = t.position();
        }

        CombatState ts = StateManager.peek(t);
        flying = ts != null && ts.flying;
        // airborne = visibly off the ground and not just standing in water: flying, launched, or falling a while
        airborne = !t.onGround() && !t.isInWater() && (flying || t.isNoGravity() || t.fallDistance > 0.6f
                || (ts != null && ts.launched));
        guarding = visible && ts != null && ts.guarding;
        stunned = visible && ts != null && (ts.hitstun > 0 || ts.punish > 0);
        launched = visible && ts != null && ts.launched;
        dodging = visible && ts != null && ts.dodgeTicks > 0;
        lunging = visible && ts != null && ts.lungeTicks > 0;
        vanishedJustNow = visible && ts != null && now - ts.vanishedAt <= 2;
        // swing animation is a public, visible property of every living entity
        swungJustNow = visible && t.swinging && t.swingTime <= 1;

        Vec3 toMe = self.position().subtract(t.position());
        Vec3 look = t.getLookAngle();
        facingMe = toMe.lengthSqr() > 1.0E-6 && look.normalize().dot(toMe.normalize()) > 0.7;
        Vec3 vel = t.position().subtract(prevPos);
        closingIn = visible && dist < 6.0 && vel.lengthSqr() > 0.04 && toMe.lengthSqr() > 1.0E-6
                && vel.normalize().dot(toMe.normalize()) > 0.6;
        prevPos = t.position();
    }

    /** Is the target close enough and pointed at me to be a likely melee threat (used for plain guard stance)? */
    public boolean nearAndFacing(double reach) {
        return visible && hitDist <= reach + 1.5 && facingMe;
    }
}
