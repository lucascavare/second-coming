package com.xenocombat.ai;

/** Combat states of the NPC's state machine. The label is what players see above the NPC. */
public enum NpcState {
    IDLE("Idle"),
    SEARCHING("Searching"),
    TARGETING("Targeting"),
    APPROACHING("Approaching"),
    COMBAT("Combat"),
    ATTACKING("Attacking"),
    COMBO("Combo"),
    HITSTUN("Hitstun"),
    BLOCKING("Blocking"),
    PARRYING("Parrying"),
    DODGING("Dodging"),
    KNOCKED_BACK("Knocked Back"),
    PURSUING("Pursuing"),
    VANISHING("Vanishing"),
    FLYING("Flying"),
    AERIAL_COMBAT("Aerial Combat"),
    RECOVERING("Recovering"),
    RETREATING("Retreating"),
    DEAD("Dead");

    private static final NpcState[] VALUES = values();
    public final String label;

    NpcState(String label) {
        this.label = label;
    }

    public static NpcState byOrdinal(int i) {
        return i >= 0 && i < VALUES.length ? VALUES[i] : IDLE;
    }
}
