package com.xenocombat.ai;

import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.CombatState;
import com.xenocombat.core.Guard;
import net.minecraft.world.entity.LivingEntity;

/**
 * Guard / parry / dodge decisions of the NPC. Everything is driven by what Perception reports plus a reaction delay,
 * so the NPC is neither omniscient nor instant:
 *  - Parry attempt: when it SEES a swing (visible swing animation, target facing it, within reach) it schedules a
 *    reaction reactionTicks later; if it rolls "parry" it raises guard then. That opens a fresh parry window, so the
 *    attempt only succeeds if the next hit happens to land inside it. Faster reactions (HARD) land more parries.
 *  - Dodge: same trigger, different roll, executed through the shared Dodge manager (same cooldown/limits as players).
 *  - Plain guard stance: when the target closes in and faces it, it may raise guard early (window already lapsed by
 *    the time a hit lands -> normal guard, not a parry).
 * A 14 tick cooldown between defensive decisions stops it from reacting to every single attack.
 */
final class BrainDefense {
    private final CombatBrain b;
    private int guardHold;
    private int reactAt = -1;
    private boolean prevSwing;
    private boolean prevNear;
    private int defenseCooldownUntil;
    private int stanceUntil;

    BrainDefense(CombatBrain b) {
        this.b = b;
    }

    void cancel() {
        guardHold = 0;
        reactAt = -1;
        if (b.s.guarding) {
            Guard.lower(b.npc, b.s);
        }
    }

    /** Returns true if defense consumed this tick (blocking, dodging) and nothing else should be decided. */
    boolean run(LivingEntity target) {
        CombatState s = b.s;
        Perception p = b.perception;
        double reach = XenoConfig.M1_REACH.get();
        long now = b.npc.level().getGameTime();

        // a perfect parry just landed: drop guard and let offense take the opening
        if (now - s.parriedAt <= 8) {
            b.setState(NpcState.PARRYING);
            if (s.guarding) {
                Guard.lower(b.npc, s);
            }
            reactAt = -1;
            return false;
        }

        // holding guard
        if (s.guarding) {
            boolean farAway = p.hitDist > reach + 3.0;
            if (--guardHold <= 0 || farAway) {
                Guard.lower(b.npc, s);
            } else {
                b.setState(NpcState.BLOCKING);
                b.move.faceToward(b.center(target), b.profile.turnDegPerTick());
                if (s.flying) {
                    b.move.brakeFlight(0.8);
                } else {
                    b.move.steer(-0.15f, 0.0f, 0.6);
                }
                return true;
            }
        }

        // committed to its own swing: no second-guessing
        if (b.offenseWindingUp()) {
            prevSwing = false;
            return false;
        }

        // 1) visible swing -> delayed reaction
        boolean swingNow = p.swungJustNow && p.facingMe && p.hitDist <= reach + 2.0;
        if (swingNow && !prevSwing && reactAt < 0) {
            reactAt = b.tick + b.profile.reactionTicks();
        }
        prevSwing = swingNow;
        if (reactAt >= 0 && b.tick >= reactAt) {
            reactAt = -1;
            if (b.tick >= defenseCooldownUntil && p.hitDist <= reach + 2.5 && s.canAct()) {
                double r = b.rnd.nextDouble();
                AiProfile prof = b.profile;
                if (r < prof.parryAttempt()) {
                    if (startGuard(10)) {
                        defenseCooldownUntil = b.tick + 14;
                        return true;
                    }
                } else if (r < prof.parryAttempt() + prof.dodge()) {
                    if (b.dodge()) {
                        defenseCooldownUntil = b.tick + 14;
                        b.setState(NpcState.DODGING);
                        return true;
                    }
                }
            }
        }

        // 2) plain guard stance when the target closes in and faces it
        boolean near = p.nearAndFacing(reach) && (p.closingIn || p.lunging || p.swungJustNow);
        if (near && !prevNear && b.tick >= stanceUntil && b.tick >= defenseCooldownUntil && s.combo == 0 && s.canAct()) {
            stanceUntil = b.tick + 40;
            if (b.rnd.nextDouble() < b.profile.guardStance() && startGuard(20 + b.rnd.nextInt(10))) {
                defenseCooldownUntil = b.tick + 10;
                prevNear = near;
                return true;
            }
        }
        prevNear = near;
        return false;
    }

    private boolean startGuard(int hold) {
        if (!b.raiseGuard()) {
            return false;
        }
        guardHold = hold;
        b.cancelOffense();
        b.setState(NpcState.BLOCKING);
        return true;
    }
}
