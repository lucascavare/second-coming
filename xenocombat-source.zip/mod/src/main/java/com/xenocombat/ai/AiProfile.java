package com.xenocombat.ai;

import com.xenocombat.config.XenoConfig;

/**
 * Difficulty parameters. These only change how often / how fast the AI decides things - never what it is allowed to
 * know or do. Config scale factors multiply the chances, and every chance is clamped below certainty so even HARD is
 * imperfect and beatable.
 */
public record AiProfile(int reactionTicks,       // delay between perceiving something and acting on it
                        double parryAttempt,     // chance to try a timed guard when a swing is seen
                        double guardStance,      // chance to raise a plain guard when the target closes in
                        double dodge,            // chance to dodge when a swing is seen
                        double vanishDefensive,  // chance to Z-Vanish out of a combo
                        double vanishOffensive,  // chance to Z-Vanish after launching the target
                        double aggression,       // chance per decision to start/continue attacking when in range
                        int comboPause,          // extra ticks between hits of a combo
                        int restBetweenCombos,   // ticks to hold off after a finished/aborted combo
                        double turnDegPerTick,   // how fast the NPC can re-aim at a moving target
                        int maxFlightTicks,      // continuous flight limit (no infinite flight)
                        double lungeChance) {

    private static final double MAX_CHANCE = 0.85;

    public static AiProfile current() {
        XenoConfig.Difficulty d = XenoConfig.NPC_DIFFICULTY.get();
        double parryScale = XenoConfig.NPC_PARRY_SCALE.get();
        double dodgeScale = XenoConfig.NPC_DODGE_SCALE.get();
        double vanishScale = XenoConfig.NPC_VANISH_SCALE.get();
        int override = XenoConfig.NPC_REACTION_OVERRIDE_TICKS.get();
        return switch (d) {
            case EASY -> new AiProfile(override >= 0 ? override : 14,
                    cap(0.10 * parryScale), cap(0.15), cap(0.10 * dodgeScale), cap(0.15 * vanishScale), cap(0.20 * vanishScale),
                    0.55, 8, 40, 10.0, 400, 0.0);
            case NORMAL -> new AiProfile(override >= 0 ? override : 8,
                    cap(0.30 * parryScale), cap(0.35), cap(0.25 * dodgeScale), cap(0.35 * vanishScale), cap(0.45 * vanishScale),
                    0.75, 4, 24, 20.0, 600, 0.25);
            case HARD -> new AiProfile(override >= 0 ? override : 4,
                    cap(0.50 * parryScale), cap(0.50), cap(0.40 * dodgeScale), cap(0.55 * vanishScale), cap(0.70 * vanishScale),
                    0.92, 1, 12, 36.0, 900, 0.5);
        };
    }

    private static double cap(double v) {
        return Math.max(0.0, Math.min(MAX_CHANCE, v));
    }
}
