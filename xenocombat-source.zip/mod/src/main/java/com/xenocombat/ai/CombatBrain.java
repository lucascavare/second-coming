package com.xenocombat.ai;

import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.CombatState;
import com.xenocombat.core.Dodge;
import com.xenocombat.core.Flight;
import com.xenocombat.core.Guard;
import com.xenocombat.core.Targeting;
import com.xenocombat.core.Vanish;
import com.xenocombat.entity.CombatNpc;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The NPC's decision maker: an explicit state machine (NpcState) re-evaluated every server tick from
 *  - what it can perceive (Perception: line of sight, visible states only, last seen position),
 *  - its own CombatState (stun, launched, cooldowns - the same object the player rules use),
 *  - a difficulty profile (reaction delay, chances, tracking speed).
 * It performs the same actions as a player through the same managers (ComboManager, Guard, Dodge, Vanish, Flight).
 * Expensive work (target search) runs every ~10 ticks only; line of sight is cached for 4 ticks.
 *
 * Split across three files: this one holds state + target handling + the tick skeleton, BrainDefense handles
 * guard/parry/dodge decisions, BrainOffense handles attack/lunge/combo + movement.
 */
public final class CombatBrain {
    /** targetId -> number of NPCs currently fighting it (server thread only). Used to spread attention. */
    private static final Map<Integer, Integer> ENGAGED = new HashMap<>();

    final CombatNpc npc;
    final CombatState s;
    final NpcMovement move;
    final Perception perception = new Perception();
    final RandomSource rnd;
    AiProfile profile = AiProfile.current();

    // ---- state machine
    private NpcState state = NpcState.IDLE;
    int tick;
    int stateTicks;
    private int profileAge;

    // ---- target
    int targetId = -1;
    int targetSince;
    private int nextSearchTick;
    private int nextSwitchTick;

    // ---- shared with defense / offense helpers
    int disorient;
    int vanishStateUntil;
    int restUntil;
    int retreatUntil;
    int flightTicks;
    int flightLockoutUntil;

    private final BrainDefense defense = new BrainDefense(this);
    private final BrainOffense offense = new BrainOffense(this);

    // ---- stun-time decisions
    private int defVanishAt = -1;
    private int lastDefRoll = -1000;
    private int seenStunAt = -1000;

    public CombatBrain(CombatNpc npc) {
        this.npc = npc;
        this.s = npc.combatState();
        this.move = npc.movement();
        this.rnd = npc.getRandom();
    }

    public NpcState state() {
        return state;
    }

    void setState(NpcState next) {
        if (next != state) {
            state = next;
            stateTicks = 0;
        }
    }

    // ================================================================== main tick

    public void tick() {
        tick++;
        stateTicks++;
        if (++profileAge >= 20) {
            profile = AiProfile.current();
            profileAge = 0;
        }
        if (!npc.isAlive()) {
            setState(NpcState.DEAD);
            return;
        }
        long now = npc.level().getGameTime();

        // ---- 1. stunned: no decisions except a possible defensive Z-Vanish
        if (s.hitstun > 0 || s.punish > 0) {
            offense.cancel();
            defense.cancel();
            move.stopPath();
            setState(s.hitstun == 0 ? NpcState.RECOVERING : (s.launched ? NpcState.KNOCKED_BACK : NpcState.HITSTUN));
            restUntil = Math.max(restUntil, tick + 6 + profile.restBetweenCombos() / 2);
            stunReaction();
            return;
        }
        defVanishAt = -1;

        // ---- 2. committed movement states
        if (tick < vanishStateUntil) {
            setState(NpcState.VANISHING);
            LivingEntity t = target();
            if (t != null) {
                move.faceToward(t.getBoundingBox().getCenter(), 90.0);
            }
            return;
        }
        if (s.lungeTicks > 0) {
            setState(NpcState.ATTACKING);
            return;
        }
        if (s.dodgeTicks > 0) {
            setState(NpcState.DODGING);
            return;
        }

        // ---- 3. target
        LivingEntity target = updateTarget();
        if (target == null) {
            idle();
            return;
        }
        perception.update(npc, target, now);
        if (!perception.visible && now - perception.lastSeenTick > 160) {
            clearTarget();
            idle();
            return;
        }
        if (!perception.visible && now - perception.lastSeenTick > 12) {
            search();
            return;
        }
        if (perception.stunned && seenStunAt < tick - 40) {
            seenStunAt = tick;
        } else if (!perception.stunned) {
            seenStunAt = -1000;
        }

        // ---- 4. reactions to what it saw
        if (perception.vanishedJustNow && disorient <= 0) {
            disorient = profile.reactionTicks() + 6; // lost the target's position for a moment
            offense.cancel();
            defense.cancel();
        }
        if (disorient > 0) {
            disorient--;
            setState(NpcState.TARGETING);
            move.stopPath();
            if (disorient < 6) {
                move.faceToward(target.getBoundingBox().getCenter(), profile.turnDegPerTick());
            }
            return;
        }
        if (tick - targetSince < profile.reactionTicks() + 4) {
            setState(NpcState.TARGETING); // just locked on: face the target before anything else
            move.faceToward(target.getBoundingBox().getCenter(), profile.turnDegPerTick());
            return;
        }

        // ---- 5. flight, defense, offense, positioning (in priority order)
        manageFlight(target);
        if (defense.run(target)) {
            return;
        }
        if (offense.run(target)) {
            return;
        }
        offense.position(target);
    }

    // ================================================================== stun-time Z-Vanish

    private void stunReaction() {
        LivingEntity target = target();
        if (tick - lastDefRoll >= 16) {
            lastDefRoll = tick;
            if (rnd.nextDouble() < profile.vanishDefensive()) {
                defVanishAt = tick + profile.reactionTicks() + rnd.nextInt(3);
            }
        }
        if (defVanishAt >= 0 && tick >= defVanishAt) {
            defVanishAt = -1;
            Vanish.Result r = Vanish.tryVanish(npc, s, target);
            if (r == Vanish.Result.DEFENSIVE) {
                vanishStateUntil = tick + 6;
                setState(NpcState.VANISHING);
            }
        }
    }

    // ================================================================== flight

    private void manageFlight(LivingEntity target) {
        if (!XenoConfig.NPC_FLIGHT_ENABLED.get() || !XenoConfig.ENABLE_FLIGHT.get()) {
            if (s.flying) {
                Flight.stop(npc, s);
            }
            return;
        }
        double dy = target.getY() - npc.getY();
        if (s.flying) {
            flightTicks++;
            boolean targetGrounded = !perception.airborne && target.onGround();
            boolean tooLong = flightTicks > profile.maxFlightTicks(); // no infinite flight
            if (tooLong || (targetGrounded && Math.abs(dy) < 1.6 && perception.dist < 7.0)) {
                Flight.stop(npc, s);
                flightLockoutUntil = tick + (tooLong ? 100 : 20);
                flightTicks = 0;
            }
            return;
        }
        if (tick < flightLockoutUntil || !s.canAct()) {
            return;
        }
        boolean targetUp = (perception.airborne && dy > 2.0) || (perception.flying && dy > 1.5);
        boolean fellFar = npc.fallDistance > 3.5f && !npc.onGround(); // knocked far up/out: catch itself
        if (targetUp || fellFar || (perception.flying && perception.dist > 12.0)) {
            if (Flight.start(npc, s)) {
                flightTicks = 0;
            }
        }
    }

    // ================================================================== targeting

    LivingEntity target() {
        return targetId >= 0 ? Targeting.byId(npc.level(), targetId) : null;
    }

    private LivingEntity updateTarget() {
        LivingEntity t = target();
        double pursuit = XenoConfig.NPC_PURSUIT_RANGE.get();
        if (t != null && (!validOpponent(t) || npc.distanceToSqr(t) > pursuit * pursuit)) {
            clearTarget();
            t = null;
        }
        if (t != null && XenoConfig.NPC_SWITCH_TARGETS.get() && tick >= nextSwitchTick) {
            nextSwitchTick = tick + 40;
            LivingEntity better = findTarget();
            if (better != null && better != t && npc.distanceTo(better) < npc.distanceTo(t) * 0.6) {
                clearTarget();
                setTarget(better);
                t = better;
            }
        }
        if (t == null && tick >= nextSearchTick) {
            nextSearchTick = tick + 10 + rnd.nextInt(5);
            t = findTarget();
            if (t != null) {
                setTarget(t);
            }
        }
        return t;
    }

    boolean validOpponent(LivingEntity e) {
        if (e == npc || !e.isAlive() || e.isRemoved()) {
            return false;
        }
        if (e instanceof Player p) {
            return !p.isCreative() && !p.isSpectator();
        }
        if (e instanceof CombatNpc) {
            return XenoConfig.NPC_FIGHT_OTHER_NPCS.get();
        }
        return XenoConfig.NPC_ATTACK_OTHER_MOBS.get();
    }

    /** One bounded AABB query (never a world scan). Needs line of sight; prefers close targets nobody else is fighting. */
    private LivingEntity findTarget() {
        double range = XenoConfig.NPC_DETECTION_RANGE.get();
        AABB box = npc.getBoundingBox().inflate(range, Math.min(range, 24.0), range);
        boolean playersOnly = !XenoConfig.NPC_FIGHT_OTHER_NPCS.get() && !XenoConfig.NPC_ATTACK_OTHER_MOBS.get();
        List<? extends LivingEntity> list = playersOnly
                ? npc.level().getEntitiesOfClass(Player.class, box, this::candidate)
                : npc.level().getEntitiesOfClass(LivingEntity.class, box, this::candidate);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double score = npc.distanceTo(e) + ENGAGED.getOrDefault(e.getId(), 0) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private boolean candidate(LivingEntity e) {
        double range = XenoConfig.NPC_DETECTION_RANGE.get();
        return validOpponent(e) && npc.distanceToSqr(e) <= range * range && npc.hasLineOfSight(e);
    }

    private void setTarget(LivingEntity t) {
        targetId = t.getId();
        targetSince = tick;
        ENGAGED.merge(targetId, 1, Integer::sum);
        perception.reset();
        setState(NpcState.TARGETING);
    }

    void clearTarget() {
        if (targetId >= 0) {
            ENGAGED.computeIfPresent(targetId, (k, v) -> v <= 1 ? null : v - 1);
        }
        targetId = -1;
        offense.cancel();
        defense.cancel();
        perception.reset();
    }

    /** Called by the entity when it takes damage: a valid attacker becomes the target if it has none. */
    public void onHurt(Entity attacker) {
        if (attacker instanceof LivingEntity le && validOpponent(le) && targetId < 0) {
            setTarget(le);
        }
    }

    /** Entity removed / died: give back the engagement slot. */
    public void release() {
        clearTarget();
    }

    // ================================================================== idle / search

    private void idle() {
        offense.cancel();
        defense.cancel();
        move.stopPath();
        if (s.flying) {
            Flight.stop(npc, s);
        }
        setState(NpcState.IDLE);
    }

    private void search() {
        setState(NpcState.SEARCHING);
        offense.cancel();
        defense.cancel();
        Vec3 last = perception.lastSeenPos;
        if (npc.position().distanceToSqr(last) > 4.0) {
            if (s.flying) {
                move.flyToward(last, XenoConfig.NPC_FLIGHT_SPEED.get(), 2.0, 0.0, 0.2);
            } else {
                move.pathTo(last, 1.0, tick);
            }
        } else {
            move.stopPath();
            move.faceToward(last.add(npc.getLookAngle().scale(3.0)), 8.0);
        }
    }

    // ================================================================== helpers used by defense/offense

    boolean offenseWindingUp() {
        return offense.isWindingUp();
    }

    void cancelOffense() {
        offense.cancel();
    }

    boolean stunSeenLongEnough() {
        return tick - seenStunAt >= Math.max(1, profile.reactionTicks() / 2);
    }

    Vec3 center(LivingEntity e) {
        return e.getBoundingBox().getCenter();
    }

    /** Shared dodge helper for the AI: sideways most often, then backward, rarely forward. */
    boolean dodge() {
        double r = rnd.nextDouble();
        int forward = r < 0.6 ? 0 : (r < 0.9 ? -1 : 1);
        int strafe = r < 0.6 ? (rnd.nextBoolean() ? 1 : -1) : 0;
        Vec3 dir = Dodge.direction(npc, forward, strafe, s.flying);
        return Dodge.start(npc, s, dir);
    }

    boolean raiseGuard() {
        return Guard.raise(npc, s);
    }
}
