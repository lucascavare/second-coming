package com.xenocombat.ai;

import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.ComboManager;
import com.xenocombat.core.CombatState;
import com.xenocombat.core.Fx;
import com.xenocombat.core.Hit;
import com.xenocombat.core.Lunge;
import com.xenocombat.core.Targeting;
import com.xenocombat.core.Vanish;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Attacking and positioning. The NPC's chain is the real 5-hit chain (CombatState.combo drives it, ComboManager performs
 * it): each hit is preceded by a short visible wind-up (longer for the first hit and the finisher, so a player can read
 * it and parry), the chain is NOT randomly cancelled between hits, and it only aborts for real reasons - target gone,
 * out of reach, dodged, parried, or the NPC got hit.
 * After the finisher the NPC knows the target is launched (pursuit window) and either chases, flies after it, or
 * Z-Vanishes to it, then keeps fighting.
 */
final class BrainOffense {
    private final CombatBrain b;
    private int windup;
    private int windupIndex;
    private boolean windupLunge;
    private int blockedStreak;
    private int nextLungeTick;
    private int nextLowHpRetreat;
    private int strafeDir = 1;
    private int strafeUntil;
    private boolean offVanishRolled;
    private int offVanishAt = -1;

    BrainOffense(CombatBrain b) {
        this.b = b;
    }

    boolean isWindingUp() {
        return windup > 0;
    }

    void cancel() {
        windup = 0;
        windupLunge = false;
    }

    // ================================================================== attacking

    /** Returns true if offense consumed this tick. */
    boolean run(LivingEntity target) {
        CombatState s = b.s;
        Perception p = b.perception;
        double reach = XenoConfig.M1_REACH.get();

        // launched target: maybe Z-Vanish after it
        if (s.pursuitTicks > 0 && s.pursuitTargetId == target.getId()) {
            if (pursuitVanish(target)) {
                return true;
            }
        } else {
            offVanishRolled = false;
            offVanishAt = -1;
        }

        // swing in progress (wind-up -> impact)
        if (windup > 0) {
            b.move.faceToward(b.center(target), b.profile.turnDegPerTick());
            if (--windup <= 0) {
                resolve(target);
            }
            return true;
        }
        if (b.tick < b.restUntil || b.tick < b.retreatUntil || s.attackCooldown > 0 || !s.canAct()) {
            return false;
        }

        boolean inReach = p.hitDist <= reach * 0.92;
        if (!inReach) {
            return maybeLunge(target);
        }
        if (p.dodging) {
            return false; // never swings at someone mid-dodge
        }
        boolean opening = p.stunned; // target is stunned / punished: seize it, but only after reaction time
        if (opening && !b.stunSeenLongEnough()) {
            return false;
        }
        if (p.guarding && !opening && blockedStreak >= 2) {
            reposition();
            return false;
        }
        if (s.combo == 0 && !opening && b.rnd.nextDouble() > b.profile.aggression()) {
            b.restUntil = b.tick + 3 + b.rnd.nextInt(4); // hesitation only BETWEEN combos, never mid-chain
            return false;
        }
        if (Targeting.angleTo(b.npc, target) > 50.0) {
            return false; // must actually be facing the target to swing
        }
        startSwing();
        return true;
    }

    private void startSwing() {
        CombatState s = b.s;
        int index = Math.min(s.combo + 1, CombatState.COMBO_LENGTH);
        windupIndex = index;
        int w = index == 1 ? 7 : (index == CombatState.COMBO_LENGTH ? 6 : 3 + b.profile.comboPause());
        if (index > 1) {
            // never let the wind-up outlast the combo window, or the chain would silently reset
            int maxW = XenoConfig.COMBO_WINDOW_TICKS.get() - XenoConfig.M1_COOLDOWN_TICKS.get() - 2;
            w = Math.max(2, Math.min(w, maxW));
        }
        windup = w;
        windupLunge = false;
        b.setState(index > 1 && index < CombatState.COMBO_LENGTH ? NpcState.COMBO : NpcState.ATTACKING);
        if (index == 1 || index == CombatState.COMBO_LENGTH) {
            Fx.lunge(b.npc); // audible telegraph for the hits that matter
        }
    }

    private void resolve(LivingEntity target) {
        CombatState s = b.s;
        if (windupLunge) {
            windupLunge = false;
            if (target.isAlive() && Targeting.isValidTarget(b.npc, target)) {
                Lunge.start(b.npc, s, target);
            }
            b.setState(NpcState.ATTACKING);
            return;
        }
        double reach = XenoConfig.M1_REACH.get();
        boolean canHit = target.isAlive()
                && Targeting.hitboxDistance(b.npc, target) <= reach
                && Targeting.angleTo(b.npc, target) <= 60.0;
        if (!canHit) {
            // the target moved away / vanished during the wind-up: the swing whiffs and the chain ends
            s.resetCombo();
            s.dirty = true;
            b.restUntil = b.tick + b.profile.restBetweenCombos() / 2;
            return;
        }
        Hit.Result r = ComboManager.swing(b.npc, s, target);
        switch (r) {
            case HIT -> {
                blockedStreak = 0;
                if (windupIndex >= CombatState.COMBO_LENGTH) {
                    onFinisher();
                }
            }
            case GUARDED -> {
                blockedStreak++;
                if (windupIndex >= CombatState.COMBO_LENGTH) {
                    b.restUntil = b.tick + b.profile.restBetweenCombos() / 2;
                }
            }
            case DODGED -> {
                s.resetCombo();
                blockedStreak = 0;
                b.restUntil = b.tick + b.profile.restBetweenCombos() / 2;
            }
            case PARRIED -> blockedStreak = 0; // the NPC is now punished; the stun branch of the brain takes over
        }
    }

    private void onFinisher() {
        b.restUntil = b.tick + b.profile.restBetweenCombos();
        b.setState(NpcState.PURSUING); // the target was just launched
    }

    private void reposition() {
        blockedStreak = 0;
        double r = b.rnd.nextDouble();
        if (r < 0.4) {
            b.retreatUntil = b.tick + 12;           // back off and reset
            b.restUntil = b.retreatUntil + 4;
        } else if (r < 0.7) {
            b.restUntil = b.tick + 14;              // wait the guard out
        }                                           // else: press on (the finisher breaks guard)
    }

    private boolean maybeLunge(LivingEntity target) {
        Perception p = b.perception;
        double reach = XenoConfig.M1_REACH.get();
        if (!XenoConfig.ENABLE_LUNGE.get() || b.profile.lungeChance() <= 0.0 || b.tick < nextLungeTick
                || p.hitDist <= reach || p.hitDist > XenoConfig.LUNGE_RANGE.get() * 0.8) {
            return false;
        }
        nextLungeTick = b.tick + 30 + b.rnd.nextInt(30);
        if (b.rnd.nextDouble() < b.profile.lungeChance() && b.npc.hasLineOfSight(target)
                && Targeting.angleTo(b.npc, target) < 35.0) {
            windup = 5;
            windupLunge = true;
            b.setState(NpcState.ATTACKING);
            return true;
        }
        return false;
    }

    private boolean pursuitVanish(LivingEntity target) {
        if (!offVanishRolled) {
            offVanishRolled = true;
            if (b.rnd.nextDouble() < b.profile.vanishOffensive()) {
                offVanishAt = b.tick + Math.max(2, b.profile.reactionTicks() / 2);
            }
        }
        if (offVanishAt >= 0 && b.tick >= offVanishAt) {
            offVanishAt = -1;
            // same Vanish manager and the same 7s cooldown as the player; fails harmlessly if not ready
            if (Vanish.tryVanish(b.npc, b.s, target) == Vanish.Result.OFFENSIVE) {
                b.vanishStateUntil = b.tick + 6;
                b.restUntil = b.tick;
                b.setState(NpcState.VANISHING);
                return true;
            }
        }
        return false;
    }

    // ================================================================== positioning

    void position(LivingEntity target) {
        CombatState s = b.s;
        Perception p = b.perception;
        double pref = XenoConfig.NPC_COMBAT_RANGE.get();
        boolean pursuing = s.pursuitTicks > 0 && s.pursuitTargetId == target.getId();
        Vec3 tc = b.center(target);
        b.move.faceToward(tc, b.profile.turnDegPerTick());

        // low health: occasionally disengage for a moment
        if (b.npc.getHealth() < b.npc.getMaxHealth() * 0.25f && b.tick >= nextLowHpRetreat) {
            b.retreatUntil = b.tick + 40;
            nextLowHpRetreat = b.tick + 140;
        }
        updateStrafe();

        if (b.tick < b.retreatUntil) {
            b.setState(NpcState.RETREATING);
            if (s.flying) {
                b.move.flyAwayFrom(tc, XenoConfig.NPC_FLIGHT_SPEED.get() * 0.8, 0.2);
            } else {
                b.move.steer(-1.0f, strafeDir * 0.3f, 1.0);
            }
            return;
        }

        if (s.flying) {
            b.setState(pursuing ? NpcState.PURSUING : (p.dist < 9.0 ? NpcState.AERIAL_COMBAT : NpcState.FLYING));
            double orbit = p.dist < 8.0 ? strafeDir * 0.8 : 0.0;
            b.move.flyToward(tc, XenoConfig.NPC_FLIGHT_SPEED.get(), pref, orbit, 0.22);
            return;
        }

        if (p.dist > 9.0) {
            b.move.pathTo(target.position(), 1.0, b.tick);
            b.setState(pursuing ? NpcState.PURSUING : NpcState.APPROACHING);
        } else if (p.dist > pref + 0.8) {
            b.move.steer(1.0f, 0.0f, 1.0);
            b.setState(pursuing ? NpcState.PURSUING : NpcState.APPROACHING);
        } else if (p.dist < pref - 1.0) {
            b.move.steer(-0.8f, strafeDir * 0.2f, 1.0); // too close: give itself room, don't stand in the hitbox
            b.setState(NpcState.COMBAT);
        } else {
            b.move.steer(0.1f, strafeDir * 0.6f, 0.9);   // circle at fighting distance
            b.setState(NpcState.COMBAT);
        }
    }

    private void updateStrafe() {
        if (b.tick >= strafeUntil) {
            strafeDir = b.rnd.nextBoolean() ? 1 : -1;
            strafeUntil = b.tick + 20 + b.rnd.nextInt(30);
        }
    }
}
