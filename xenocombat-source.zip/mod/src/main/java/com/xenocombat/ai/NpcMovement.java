package com.xenocombat.ai;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/**
 * Movement primitives for the NPC. Ground combat steering uses the vanilla MoveControl STRAFE operation (forward +
 * sideways relative to the body), long-range approaches use the vanilla pathfinder, and flight sets velocity directly
 * (gravity is switched off by Flight while flying). Nothing here teleports and everything obeys collisions.
 */
public final class NpcMovement {
    private final Mob mob;
    private int lastPathTick = -100;

    public NpcMovement(Mob mob) {
        this.mob = mob;
    }

    /** Turn the body/head toward a point at a limited rate (degrees per tick). Returns the remaining yaw error. */
    public float faceToward(Vec3 point, double maxDegPerTick) {
        double dx = point.x - mob.getX();
        double dz = point.z - mob.getZ();
        double dy = point.y - mob.getEyeY();
        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        float err = Mth.wrapDegrees(wantYaw - mob.getYRot());
        float step = (float) Mth.clamp(err, -maxDegPerTick, maxDegPerTick);
        float yaw = mob.getYRot() + step;
        mob.setYRot(yaw);
        mob.setYHeadRot(yaw);
        mob.setYBodyRot(yaw);
        mob.setXRot(mob.getXRot() + Mth.clamp(wantPitch - mob.getXRot(), -(float) maxDegPerTick, (float) maxDegPerTick));
        return Mth.wrapDegrees(wantYaw - yaw);
    }

    /** Path toward a point with the vanilla navigator; re-planned at most every 10 ticks. */
    public void pathTo(Vec3 pos, double speed, int tick) {
        if (tick - lastPathTick >= 10 || mob.getNavigation().isDone()) {
            mob.getNavigation().moveTo(pos.x, pos.y, pos.z, speed);
            lastPathTick = tick;
        }
    }

    public void stopPath() {
        if (!mob.getNavigation().isDone()) {
            mob.getNavigation().stop();
        }
    }

    /** Direct steering relative to the body: forward/strafe in [-1, 1]. Call every tick you want to move. */
    public void steer(float forward, float strafe, double speed) {
        stopPath();
        mob.getMoveControl().setWantedPosition(mob.getX(), mob.getY(), mob.getZ(), speed);
        mob.getMoveControl().strafe(forward, strafe);
        if (mob.horizontalCollision && mob.onGround()) {
            mob.getJumpControl().jump();
        }
    }

    /**
     * Flight: steer toward a goal with a velocity cap, stopping near it. 'orbit' adds sideways motion
     * (-1..1) around the line to the goal so the NPC doesn't just hang still in a fight.
     */
    public void flyToward(Vec3 goal, double maxSpeed, double stopDistance, double orbit, double accel) {
        Vec3 center = mob.getBoundingBox().getCenter();
        Vec3 to = goal.subtract(center);
        double d = to.length();
        Vec3 desired = Vec3.ZERO;
        if (d > 1.0E-4) {
            Vec3 dir = to.scale(1.0 / d);
            double speed = d > stopDistance ? Math.min(maxSpeed, Math.max(0.08, (d - stopDistance) * 0.35)) : 0.0;
            desired = dir.scale(speed);
            if (orbit != 0.0) {
                Vec3 side = new Vec3(-dir.z, 0.0, dir.x);
                desired = desired.add(side.scale(orbit * maxSpeed * 0.5));
            }
        }
        Vec3 cur = mob.getDeltaMovement();
        mob.setDeltaMovement(cur.add(desired.subtract(cur).scale(accel)));
        mob.fallDistance = 0.0f;
    }

    /** Back away along the line from a point, on the ground or in the air. */
    public void flyAwayFrom(Vec3 from, double speed, double accel) {
        Vec3 away = mob.getBoundingBox().getCenter().subtract(from);
        if (away.lengthSqr() < 1.0E-6) {
            return;
        }
        Vec3 desired = away.normalize().scale(speed);
        Vec3 cur = mob.getDeltaMovement();
        mob.setDeltaMovement(cur.add(desired.subtract(cur).scale(accel)));
    }

    public void brakeFlight(double factor) {
        mob.setDeltaMovement(mob.getDeltaMovement().scale(factor));
    }
}
