package com.xenocombat.entity;

import com.xenocombat.XenoCombat;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Entity type, spawn egg, attributes, creative tab entry and (config-gated) natural spawn placement. */
public final class XenoRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, XenoCombat.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, XenoCombat.MODID);

    public static final RegistryObject<EntityType<CombatNpc>> COMBAT_NPC = ENTITIES.register("combat_npc",
            () -> EntityType.Builder.<CombatNpc>of(CombatNpc::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .build("combat_npc"));

    public static final RegistryObject<Item> COMBAT_NPC_EGG = ITEMS.register("combat_npc_spawn_egg",
            () -> new ForgeSpawnEggItem(COMBAT_NPC, 0xB02020, 0xF0B030, new Item.Properties()));

    public static void register(IEventBus modBus) {
        ENTITIES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(XenoRegistry::onAttributes);
        modBus.addListener(XenoRegistry::onCreativeTab);
        modBus.addListener(XenoRegistry::onSpawnPlacement);
    }

    private static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(COMBAT_NPC.get(), CombatNpc.createAttributes().build());
    }

    private static void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(COMBAT_NPC_EGG);
        }
    }

    private static void onSpawnPlacement(SpawnPlacementRegisterEvent event) {
        event.register(COMBAT_NPC.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                CombatNpc::checkSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
    }

    private XenoRegistry() {}
}
