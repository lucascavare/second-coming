package com.xenocombat.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.xenocombat.XenoCombat;
import com.xenocombat.ai.NpcState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Humanoid renderer for the combat NPC: guard pose while blocking/parrying and a combat-state label above its head. */
public class CombatNpcRenderer extends HumanoidMobRenderer<CombatNpc, HumanoidModel<CombatNpc>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(XenoCombat.MODID, "textures/entity/combat_npc.png");

    public CombatNpcRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(CombatNpc npc) {
        return TEXTURE;
    }

    @Override
    public void render(CombatNpc npc, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        NpcState state = npc.npcState();
        boolean blocking = state == NpcState.BLOCKING || state == NpcState.PARRYING;
        HumanoidModel.ArmPose arms = blocking ? HumanoidModel.ArmPose.BLOCK : HumanoidModel.ArmPose.EMPTY;
        this.model.rightArmPose = arms;
        this.model.leftArmPose = arms;
        super.render(npc, yaw, partialTick, pose, buffers, light);
    }

    @Override
    protected boolean shouldShowName(CombatNpc npc) {
        double d = this.entityRenderDispatcher.distanceToSqr(npc);
        return npc.isAlive() && d < 48.0 * 48.0;
    }

    @Override
    protected void renderNameTag(CombatNpc npc, Component name, PoseStack pose, MultiBufferSource buffers, int light) {
        // the label is read from synced entity data, so every client sees the NPC's current combat state
        Component label = Component.literal("Xeno Fighter [" + npc.npcState().label + "]");
        super.renderNameTag(npc, label, pose, buffers, light);
    }
}
