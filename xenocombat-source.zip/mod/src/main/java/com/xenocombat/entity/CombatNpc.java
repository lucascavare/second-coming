package com.xenocombat.entity;

import com.xenocombat.ai.CombatBrain;
import com.xenocombat.ai.NpcMovement;
import com.xenocombat.ai.NpcState;
import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.CombatState;
import com.xenocombat.core.CombatTicker;
import com.xenocombat.core.ICombatant;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

/**
 * The combat NPC ("Xeno Fighter"). It does not use vanilla attack/target goals: all decisions come from CombatBrain,
 * and all combat rules (M1 chain, hitstun, guard, parry, dodge, Z-Vanish, flight) are the same code the player uses,
 * operating on this entity's own CombatState.
 */
public class CombatNpc extends PathfinderMob implements ICombatant {
    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(CombatNpc.class, EntityDataSerializers.INT);

    private final CombatState combat = new CombatState();
    private final NpcMovement movement = new NpcMovement(this);
    private CombatBrain brain;
    private boolean configApplied;
    private boolean newSpawn;

    public CombatNpc(EntityType<? extends CombatNpc> type, Level level) {
        super(type, level);
        this.xpReward = 20;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100.0)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.ARMOR, 4.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.FOLLOW_RANGE, 28.0)
                .add(Attributes.FLYING_SPEED, 0.5);
    }

    public static boolean checkSpawnRules(EntityType<CombatNpc> type, ServerLevelAccessor level, MobSpawnType reason,
                                          BlockPos pos, RandomSource random) {
        return XenoConfig.NPC_NATURAL_SPAWN.get() && Monster.checkMonsterSpawnRules(type, level, reason, pos, random);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this)); // only keeps it afloat; all combat is CombatBrain
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, NpcState.IDLE.ordinal());
    }

    // ------------------------------------------------------------------ ICombatant

    @Override
    public CombatState combatState() {
        return combat;
    }

    @Override
    public float m1Damage() {
        return (float) getAttributeValue(Attributes.ATTACK_DAMAGE);
    }

    public NpcMovement movement() {
        return movement;
    }

    public CombatBrain brain() {
        if (brain == null) {
            brain = new CombatBrain(this);
        }
        return brain;
    }

    public NpcState npcState() {
        return NpcState.byOrdinal(this.entityData.get(DATA_STATE));
    }

    // ------------------------------------------------------------------ server tick

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!configApplied) {
            applyConfig();
        }
        CombatTicker.tick(this, combat);
        if (XenoConfig.ENABLE_NPC_AI.get()) {
            brain().tick();
            this.entityData.set(DATA_STATE, brain().state().ordinal());
        }
    }

    /** Attributes come from the common config, applied on the first server tick (and re-applied if never done). */
    private void applyConfig() {
        setBase(Attributes.MAX_HEALTH, XenoConfig.NPC_HEALTH.get());
        setBase(Attributes.ATTACK_DAMAGE, XenoConfig.NPC_DAMAGE.get());
        setBase(Attributes.ARMOR, XenoConfig.NPC_ARMOR.get());
        setBase(Attributes.MOVEMENT_SPEED, XenoConfig.NPC_SPEED.get());
        setBase(Attributes.FLYING_SPEED, XenoConfig.NPC_FLIGHT_SPEED.get());
        setBase(Attributes.FOLLOW_RANGE, XenoConfig.NPC_DETECTION_RANGE.get());
        if (newSpawn) {
            setHealth(getMaxHealth());
        } else if (getHealth() > getMaxHealth()) {
            setHealth(getMaxHealth());
        }
        configApplied = true;
    }

    private void setBase(Attribute attribute, double value) {
        AttributeInstance inst = getAttribute(attribute);
        if (inst != null) {
            inst.setBaseValue(value);
        }
    }

    // ------------------------------------------------------------------ lifecycle / events

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        newSpawn = true;
        if (reason != MobSpawnType.NATURAL && reason != MobSpawnType.CHUNK_GENERATION) {
            setPersistenceRequired(); // eggs, /summon and spawners never despawn
        }
        applyConfig();
        return data;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && !level().isClientSide) {
            brain().onHurt(source.getEntity());
        }
        return result;
    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide) {
            brain().release();
        }
        super.die(source);
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && brain != null) {
            brain.release();
        }
        super.remove(reason);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return 1;
    }
}
