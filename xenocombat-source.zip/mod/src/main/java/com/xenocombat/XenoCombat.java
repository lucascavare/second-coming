package com.xenocombat;

import com.xenocombat.config.XenoCommands;
import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.CombatEvents;
import com.xenocombat.entity.XenoRegistry;
import com.xenocombat.network.XenoNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

@Mod(XenoCombat.MODID)
public class XenoCombat {
    public static final String MODID = "xenocombat";
    public static final Logger LOGGER = LogUtils.getLogger();

    public XenoCombat() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModLoadingContext ctx = ModLoadingContext.get();
        ctx.registerConfig(ModConfig.Type.COMMON, XenoConfig.COMMON_SPEC);
        ctx.registerConfig(ModConfig.Type.CLIENT, XenoConfig.CLIENT_SPEC);

        XenoRegistry.register(modBus);
        modBus.addListener(this::commonSetup);

        MinecraftForge.EVENT_BUS.register(new CombatEvents());
        MinecraftForge.EVENT_BUS.register(new XenoCommands());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(XenoNetwork::register);
    }
}
