package com.xenocombat.network;

import com.xenocombat.core.Action;
import com.xenocombat.core.ServerActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server request. The server validates everything (cooldowns, state, range); nothing here is trusted. */
public record ActionPacket(Action action, int arg) {

    public static void encode(ActionPacket p, FriendlyByteBuf buf) {
        buf.writeByte(p.action.ordinal());
        buf.writeInt(p.arg);
    }

    public static ActionPacket decode(FriendlyByteBuf buf) {
        Action a = Action.byOrdinal(buf.readByte());
        int arg = buf.readInt();
        return new ActionPacket(a, arg);
    }

    public static void handle(ActionPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        ServerPlayer sender = c.getSender();
        if (sender != null && p.action != null) {
            ServerActions.handle(sender, p.action, p.arg);
        }
        c.setPacketHandled(true);
    }
}
