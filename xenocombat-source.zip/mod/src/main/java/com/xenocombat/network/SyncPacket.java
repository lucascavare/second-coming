package com.xenocombat.network;

import com.xenocombat.client.ClientCombatData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> owning client snapshot of that player's combat state. Sent only when something changed
 * (see SyncManager), never every tick. The client uses it to block input during hitstun, show the
 * Z-Vanish cooldown, drive flight and keep the lock-on target valid.
 */
public record SyncPacket(int hitstun, int vanishCooldown, int dodgeCooldown, int combo,
                         boolean flying, boolean guarding, boolean launched, int lockTargetId) {

    public static void encode(SyncPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.hitstun);
        buf.writeVarInt(p.vanishCooldown);
        buf.writeVarInt(p.dodgeCooldown);
        buf.writeByte(p.combo);
        int flags = (p.flying ? 1 : 0) | (p.guarding ? 2 : 0) | (p.launched ? 4 : 0);
        buf.writeByte(flags);
        buf.writeInt(p.lockTargetId);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        int hitstun = buf.readVarInt();
        int vanish = buf.readVarInt();
        int dodge = buf.readVarInt();
        int combo = buf.readByte();
        int flags = buf.readByte();
        int lock = buf.readInt();
        return new SyncPacket(hitstun, vanish, dodge, combo, (flags & 1) != 0, (flags & 2) != 0, (flags & 4) != 0, lock);
    }

    public static void handle(SyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientCombatData.apply(p));
        c.setPacketHandled(true);
    }
}
