package com.xenocombat.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Minimal text HUD: lock-on target, combo count, Z-Vanish ready/cooldown, guard / flight / stun indicators.
 * Deliberately plain text: there are no resource bars in this mod (no ki, stamina or energy).
 */
public final class XenoHud {
    public static final IGuiOverlay OVERLAY = XenoHud::render;

    private static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.screen != null) {
            return;
        }
        int y = h / 2 + 24;
        int cx = w / 2;

        int id = ClientCombatData.lockTargetId;
        if (id != -1 && mc.level != null) {
            Entity t = mc.level.getEntity(id);
            if (t != null) {
                draw(g, mc, Component.literal("LOCK  " + t.getName().getString()), cx, y, 0xFFFFAA33);
                y += 11;
            }
        }
        if (ClientCombatData.combo > 0) {
            draw(g, mc, Component.literal("COMBO  " + ClientCombatData.combo + " / 5"), cx, y, 0xFFFFFFFF);
            y += 11;
        }
        int cd = ClientCombatData.vanishCooldown;
        if (cd > 0) {
            draw(g, mc, Component.literal(String.format("Z-VANISH  %.1fs", cd / 20.0)), cx, y, 0xFF8899AA);
        } else {
            draw(g, mc, Component.literal("Z-VANISH  READY"), cx, y, 0xFF55FFFF);
        }
        y += 11;
        if (ClientCombatData.guarding) {
            draw(g, mc, Component.literal("GUARD"), cx, y, 0xFF66AAFF);
            y += 11;
        }
        if (ClientCombatData.flying) {
            draw(g, mc, Component.literal("FLIGHT"), cx, y, 0xFFAAFFAA);
            y += 11;
        }
        if (ClientCombatData.isHitstunned()) {
            draw(g, mc, Component.literal("STUNNED"), cx, y, 0xFFFF5555);
        }
    }

    private static void draw(GuiGraphics g, Minecraft mc, Component text, int cx, int y, int color) {
        g.drawCenteredString(mc.font, text, cx, y, color);
    }

    private XenoHud() {}
}
