package com.xenocombat.client;

import com.xenocombat.config.XenoConfig;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side flight motion. Vanilla player positions are client-authoritative, so velocity is computed here from the
 * flight keybinds; the server decides *whether* the player is flying (ClientCombatData.flying only turns true after the
 * server confirmed it) and owns gravity, fall damage and the anti-kick bookkeeping.
 *
 * Forward follows the look vector (which the lock-on camera keeps on the target), strafe is perpendicular, ascend /
 * descend are world-vertical, boost raises the target speed. Acceleration closes a fraction of the speed gap per tick
 * and turning blends the direction of travel toward the wished direction, both configurable.
 */
public final class ClientFlight {

    public static void tick(LocalPlayer p) {
        if (!ClientCombatData.flying) {
            return;
        }
        p.getAbilities().flying = false; // never let double-tap-jump creative flight take over
        if (ClientCombatData.hitstun > 0) {
            return; // stunned flyers follow the launch arc instead of steering
        }
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        flat = flat.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : flat.normalize();
        Vec3 right = new Vec3(-flat.z, 0.0, flat.x);

        int fwd = axis(XenoKeys.FLY_FORWARD.isDown(), XenoKeys.FLY_BACKWARD.isDown());
        int str = axis(XenoKeys.FLY_RIGHT.isDown(), XenoKeys.FLY_LEFT.isDown());
        int up = axis(XenoKeys.FLY_ASCEND.isDown(), XenoKeys.FLY_DESCEND.isDown());

        Vec3 wish = look.scale(fwd).add(right.scale(str)).add(0.0, up, 0.0);
        double topSpeed = XenoKeys.FLY_BOOST.isDown() ? XenoConfig.FLIGHT_BOOST_SPEED.get() : XenoConfig.FLIGHT_SPEED.get();
        double targetSpeed = wish.lengthSqr() > 1.0E-6 ? topSpeed : 0.0;
        Vec3 wishDir = wish.lengthSqr() > 1.0E-6 ? wish.normalize() : Vec3.ZERO;

        Vec3 cur = p.getDeltaMovement();
        double curSpeed = cur.length();
        Vec3 dir;
        if (curSpeed < 0.02 || wishDir == Vec3.ZERO) {
            dir = wishDir == Vec3.ZERO ? (curSpeed < 1.0E-4 ? Vec3.ZERO : cur.normalize()) : wishDir;
        } else {
            Vec3 d0 = cur.normalize();
            double t = XenoConfig.FLIGHT_TURN_LERP.get();
            Vec3 blended = d0.add(wishDir.subtract(d0).scale(t));
            dir = blended.lengthSqr() < 1.0E-8 ? wishDir : blended.normalize();
        }
        double accel = XenoConfig.FLIGHT_ACCELERATION.get();
        double speed = curSpeed + (targetSpeed - curSpeed) * accel;
        if (speed < 0.01 && targetSpeed == 0.0) {
            speed = 0.0;
        }
        p.setDeltaMovement(dir.scale(speed));
        p.fallDistance = 0.0f;
    }

    private static int axis(boolean positive, boolean negative) {
        return (positive ? 1 : 0) - (negative ? 1 : 0);
    }

    private ClientFlight() {}
}
