package com.xenocombat.client;

import com.xenocombat.config.ConfigAccess;
import com.xenocombat.config.XenoConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * In-game configuration screen (Mods list -> Xeno Combat -> Config). Generated from the config specs, so every option
 * (combat, defense, vanish, flight, targeting, AI, camera, feature toggles) is here without per-option code. Booleans and
 * enums are click-to-cycle buttons, numbers are validated text boxes. Done validates everything, then writes the files.
 * Hover a row for its description.
 */
public class XenoConfigScreen extends Screen {
    private static final int PER_PAGE = 7;

    private record Entry(ForgeConfigSpec spec, ForgeConfigSpec.ConfigValue<?> cv, String path, String comment) {}

    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();
    private final Map<String, String> pending = new HashMap<>();
    private int page;
    private String status = "";
    private int statusColor = 0xFFFF5555;

    public XenoConfigScreen(Screen parent) {
        super(Component.literal("Xeno Combat Settings"));
        this.parent = parent;
        addAll(XenoConfig.COMMON_SPEC);
        addAll(XenoConfig.CLIENT_SPEC);
    }

    private void addAll(ForgeConfigSpec spec) {
        for (ForgeConfigSpec.ConfigValue<?> cv : ConfigAccess.values(spec)) {
            entries.add(new Entry(spec, cv, ConfigAccess.path(cv), ConfigAccess.comment(spec, cv)));
        }
    }

    private int pageCount() {
        return Math.max(1, (entries.size() + PER_PAGE - 1) / PER_PAGE);
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 160;
        int top = 40;
        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < entries.size(); i++) {
            Entry e = entries.get(start + i);
            int y = top + i * 24;
            String key = e.path();
            String shown = pending.computeIfAbsent(key, k -> String.valueOf(e.cv().get()));
            Object val = e.cv().get();
            if (val instanceof Boolean || val instanceof Enum<?>) {
                addRenderableWidget(Button.builder(Component.literal(shown), b -> {
                    String next = nextValue(e, pending.get(key));
                    pending.put(key, next);
                    b.setMessage(Component.literal(next));
                }).bounds(left + 190, y, 130, 20).build());
            } else {
                EditBox box = new EditBox(this.font, left + 190, y, 130, 20, Component.literal(key));
                box.setValue(shown);
                box.setResponder(text -> pending.put(key, text));
                addRenderableWidget(box);
            }
        }
        int bottom = this.height - 28;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> changePage(-1))
                .bounds(left, bottom, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> changePage(1))
                .bounds(left + 280, bottom, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> done())
                .bounds(left + 50, bottom, 110, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose())
                .bounds(left + 170, bottom, 100, 20).build());
    }

    private void changePage(int delta) {
        page = Math.floorMod(page + delta, pageCount());
        rebuildWidgets();
    }

    private static String nextValue(Entry e, String current) {
        Object val = e.cv().get();
        if (val instanceof Boolean) {
            return String.valueOf(!Boolean.parseBoolean(current));
        }
        Enum<?>[] all = ((Enum<?>) val).getDeclaringClass().getEnumConstants();
        for (int i = 0; i < all.length; i++) {
            if (all[i].name().equalsIgnoreCase(current)) {
                return all[(i + 1) % all.length].name();
            }
        }
        return all[0].name();
    }

    private void done() {
        for (Entry e : entries) {
            String text = pending.get(e.path());
            if (text == null || text.equals(String.valueOf(e.cv().get()))) {
                continue;
            }
            String error = ConfigAccess.apply(e.spec(), e.cv(), text);
            if (error != null) {
                status = e.path() + ": " + error;
                statusColor = 0xFFFF5555;
                return; // stay open so the value can be corrected
            }
        }
        XenoConfig.COMMON_SPEC.save();
        XenoConfig.CLIENT_SPEC.save();
        onClose();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFFFF);
        g.drawCenteredString(this.font, Component.literal("Page " + (page + 1) + " / " + pageCount()), this.width / 2, 26, 0xFFAAAAAA);
        int left = this.width / 2 - 160;
        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < entries.size(); i++) {
            Entry e = entries.get(start + i);
            int y = 40 + i * 24;
            g.drawString(this.font, e.path(), left, y + 6, 0xFFFFFFFF);
        }
        boolean remote = this.minecraft != null && this.minecraft.level != null && this.minecraft.getSingleplayerServer() == null;
        if (remote) {
            g.drawCenteredString(this.font, Component.literal("Connected to a server: combat rules come from the SERVER's config (use /xenocombat)."),
                    this.width / 2, this.height - 44, 0xFFFFAA33);
        }
        if (!status.isEmpty()) {
            g.drawCenteredString(this.font, Component.literal(status), this.width / 2, this.height - 56, statusColor);
        }
        super.render(g, mouseX, mouseY, partialTick);
        for (int i = 0; i < PER_PAGE && start + i < entries.size(); i++) {
            Entry e = entries.get(start + i);
            int y = 40 + i * 24;
            if (mouseY >= y && mouseY < y + 20 && mouseX >= left && mouseX < left + 190 && !e.comment().isEmpty()) {
                g.renderTooltip(this.font, Component.literal(e.comment().trim()), mouseX, mouseY);
            }
        }
    }
}
