package com.xenocombat.client;

import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.Action;
import com.xenocombat.core.Targeting;
import com.xenocombat.network.ActionPacket;
import com.xenocombat.network.XenoNetwork;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Client half of lock-on. The client only PICKS a candidate (nearest to the crosshair) and asks; the server validates
 * and confirms through SyncPacket.lockTargetId. The camera, the outline and everything else follow the confirmed id,
 * so a rejected request has no effect.
 */
public final class LockOnClient {
    private static int glowId = -1;
    private static boolean cameraWasForced;
    private static CameraType previousCamera;

    /** Lock key pressed: acquire, switch (while sneaking) or release. */
    public static void onLockKey(Minecraft mc, LocalPlayer p) {
        if (!XenoConfig.ENABLE_LOCK_ON.get()) {
            return;
        }
        int current = ClientCombatData.lockTargetId;
        if (current != -1 && !p.isShiftKeyDown()) {
            XenoNetwork.sendToServer(new ActionPacket(Action.LOCK, -1));
            return;
        }
        LivingEntity exclude = current != -1 && mc.level.getEntity(current) instanceof LivingEntity le ? le : null;
        LivingEntity cand = Targeting.findLockCandidate(p, XenoConfig.LOCK_ON_RANGE.get(), XenoConfig.LOCK_ON_LOS.get(), exclude);
        if (cand == null && exclude != null) {
            return; // nothing else to switch to: keep the current lock
        }
        if (cand != null) {
            XenoNetwork.sendToServer(new ActionPacket(Action.LOCK, cand.getId()));
        }
    }

    /** Called every client tick: outline + optional third-person while locked. */
    public static void tick(Minecraft mc, LocalPlayer p) {
        int id = ClientCombatData.lockTargetId;
        if (id != glowId) {
            setGlow(mc, glowId, false);
            setGlow(mc, id, true);
            glowId = id;
            handleCameraType(mc, id != -1);
        } else if (id != -1 && mc.level.getEntity(id) == null) {
            glowId = -1; // target unloaded client-side; server will clear the lock shortly
        }
    }

    /** Called every frame (render tick) so the turn toward the target is smooth regardless of tick rate. */
    public static void aim(Minecraft mc, LocalPlayer p, float frameTicks) {
        if (!XenoConfig.ENABLE_COMBAT_CAMERA.get() || !XenoConfig.CAM_LOCK_ON.get()) {
            return;
        }
        int id = ClientCombatData.lockTargetId;
        if (id == -1 || ClientCombatData.hitstun > 0 && ClientCombatData.launched) {
            return; // let a launched player look around while tumbling
        }
        Entity t = mc.level.getEntity(id);
        if (t == null || mc.screen != null) {
            return;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 to = t.getBoundingBox().getCenter().subtract(eye);
        double horiz = Math.sqrt(to.x * to.x + to.z * to.z);
        float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(to.y, horiz));
        double smooth = XenoConfig.CAM_SMOOTHING.get();
        float f = (float) (1.0 - Math.pow(1.0 - smooth, Math.max(0.2f, frameTicks)));
        float dYaw = Mth.wrapDegrees(wantYaw - p.getYRot()) * f;
        float dPitch = (wantPitch - p.getXRot()) * f;
        p.turn(dYaw / 0.15, dPitch / 0.15); // Entity.turn scales by 0.15 and keeps the previous-rotation fields consistent
    }

    public static void reset(Minecraft mc) {
        setGlow(mc, glowId, false);
        glowId = -1;
        cameraWasForced = false;
    }

    private static void setGlow(Minecraft mc, int id, boolean on) {
        if (id < 0 || mc.level == null) {
            return;
        }
        Entity e = mc.level.getEntity(id);
        if (e != null) {
            e.setGlowingTag(on); // client-only outline, never sent to the server
        }
    }

    private static void handleCameraType(Minecraft mc, boolean locked) {
        if (!XenoConfig.CAM_FORCE_THIRD_PERSON.get()) {
            return;
        }
        if (locked && mc.options.getCameraType() == CameraType.FIRST_PERSON) {
            previousCamera = CameraType.FIRST_PERSON;
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            cameraWasForced = true;
        } else if (!locked && cameraWasForced) {
            mc.options.setCameraType(previousCamera != null ? previousCamera : CameraType.FIRST_PERSON);
            cameraWasForced = false;
        }
    }

    private LockOnClient() {}
}
