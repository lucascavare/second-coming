package com.xenocombat.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.IKeyConflictContext;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** All custom controls. Registered through Minecraft's key mapping system -> Options > Controls > Key Binds. */
public final class XenoKeys {
    public static final String CATEGORY = "key.categories.xenocombat";

    /**
     * Flight movement keys only "exist" while flying, and only conflict with each other,
     * so their default W/A/S/D/Space/Ctrl don't show as conflicts with vanilla movement.
     */
    public static final IKeyConflictContext FLIGHT_CONTEXT = new IKeyConflictContext() {
        @Override
        public boolean isActive() {
            return ClientCombatData.flying;
        }

        @Override
        public boolean conflicts(IKeyConflictContext other) {
            return other == this;
        }
    };

    public static final KeyMapping LOCK_ON = key("lock_on", KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_R);
    public static final KeyMapping GUARD = key("guard", KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_G);
    public static final KeyMapping VANISH = key("z_vanish", KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_Z);
    public static final KeyMapping DODGE = key("dodge", KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_V);
    public static final KeyMapping FLIGHT_TOGGLE = key("flight_toggle", KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_H);

    public static final KeyMapping FLY_FORWARD = key("fly_forward", FLIGHT_CONTEXT, GLFW.GLFW_KEY_W);
    public static final KeyMapping FLY_BACKWARD = key("fly_backward", FLIGHT_CONTEXT, GLFW.GLFW_KEY_S);
    public static final KeyMapping FLY_LEFT = key("fly_left", FLIGHT_CONTEXT, GLFW.GLFW_KEY_A);
    public static final KeyMapping FLY_RIGHT = key("fly_right", FLIGHT_CONTEXT, GLFW.GLFW_KEY_D);
    public static final KeyMapping FLY_ASCEND = key("fly_ascend", FLIGHT_CONTEXT, GLFW.GLFW_KEY_SPACE);
    public static final KeyMapping FLY_DESCEND = key("fly_descend", FLIGHT_CONTEXT, GLFW.GLFW_KEY_LEFT_CONTROL);
    public static final KeyMapping FLY_BOOST = key("fly_boost", FLIGHT_CONTEXT, GLFW.GLFW_KEY_LEFT_SHIFT);

    private static KeyMapping key(String name, IKeyConflictContext ctx, int code) {
        return new KeyMapping("key.xenocombat." + name, ctx, InputConstants.Type.KEYSYM, code, CATEGORY);
    }

    public static void register(RegisterKeyMappingsEvent event) {
        event.register(LOCK_ON);
        event.register(GUARD);
        event.register(VANISH);
        event.register(DODGE);
        event.register(FLIGHT_TOGGLE);
        event.register(FLY_FORWARD);
        event.register(FLY_BACKWARD);
        event.register(FLY_LEFT);
        event.register(FLY_RIGHT);
        event.register(FLY_ASCEND);
        event.register(FLY_DESCEND);
        event.register(FLY_BOOST);
    }

    private XenoKeys() {}
}
