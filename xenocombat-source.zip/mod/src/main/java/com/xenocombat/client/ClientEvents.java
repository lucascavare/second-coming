package com.xenocombat.client;

import com.xenocombat.XenoCombat;
import com.xenocombat.config.XenoConfig;
import com.xenocombat.core.Action;
import com.xenocombat.core.Dodge;
import com.xenocombat.network.ActionPacket;
import com.xenocombat.network.XenoNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Gameplay-time client events (forge bus). Everything here only REQUESTS actions from the server; hitstun blocking
 * is a courtesy so the player feels the stun, the server independently rejects every action taken while stunned.
 */
@Mod.EventBusSubscriber(modid = XenoCombat.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static boolean guardSent;
    private static int ticksSinceM1 = 100;
    private static int ticksSinceGuardRetry;

    // ------------------------------------------------------------------ attack interception

    /** Standard attack input -> custom M1. Mining a block you are looking at (while not locked/flying) stays vanilla. */
    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered e) {
        if (!e.isAttack()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !useCombatAttack(mc)) {
            return;
        }
        e.setCanceled(true);
        e.setSwingHand(false); // the server plays the swing animation
        sendM1();
    }

    private static boolean useCombatAttack(Minecraft mc) {
        if (ClientCombatData.lockTargetId != -1 || ClientCombatData.flying) {
            return true;
        }
        HitResult hit = mc.hitResult;
        return hit == null || hit.getType() != HitResult.Type.BLOCK;
    }

    private static void sendM1() {
        if (ClientCombatData.isHitstunned()) {
            return;
        }
        ticksSinceM1 = 0;
        XenoNetwork.sendToServer(new ActionPacket(Action.M1, 0));
    }

    // ------------------------------------------------------------------ per-tick input

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            return;
        }
        ClientCombatData.tick();
        LockOnClient.tick(mc, p);
        ticksSinceM1++;

        if (mc.screen != null) {
            releaseGuardIfHeld();
            return;
        }

        // ---- discrete presses
        while (XenoKeys.LOCK_ON.consumeClick()) {
            LockOnClient.onLockKey(mc, p);
        }
        while (XenoKeys.FLIGHT_TOGGLE.consumeClick()) {
            XenoNetwork.sendToServer(new ActionPacket(Action.FLIGHT_TOGGLE, 0));
        }
        while (XenoKeys.VANISH.consumeClick()) {
            XenoNetwork.sendToServer(new ActionPacket(Action.VANISH, 0));
        }
        while (XenoKeys.DODGE.consumeClick()) {
            if (!ClientCombatData.isHitstunned()) {
                XenoNetwork.sendToServer(new ActionPacket(Action.DODGE, dodgeArg(mc)));
            }
        }

        // ---- guard (hold). The server owns the parry window: it counts from the moment GUARD_ON is processed.
        boolean down = XenoKeys.GUARD.isDown() && !ClientCombatData.isHitstunned();
        if (down && !guardSent) {
            XenoNetwork.sendToServer(new ActionPacket(Action.GUARD_ON, 0));
            guardSent = true;
            ticksSinceGuardRetry = 0;
        } else if (!XenoKeys.GUARD.isDown() && guardSent) {
            XenoNetwork.sendToServer(new ActionPacket(Action.GUARD_OFF, 0));
            guardSent = false;
        } else if (down && guardSent && !ClientCombatData.guarding && ++ticksSinceGuardRetry >= 6) {
            // key still held but the server dropped guard (stun / dodge / guard lock): ask again
            XenoNetwork.sendToServer(new ActionPacket(Action.GUARD_ON, 0));
            ticksSinceGuardRetry = 0;
        }

        // ---- held attack repeats the combo (vanilla only repeats for block breaking)
        if (mc.options.keyAttack.isDown() && useCombatAttack(mc) && !ClientCombatData.isHitstunned()
                && ticksSinceM1 >= XenoConfig.M1_COOLDOWN_TICKS.get() + 1) {
            sendM1();
        }

        ClientFlight.tick(p);
    }

    private static void releaseGuardIfHeld() {
        if (guardSent) {
            XenoNetwork.sendToServer(new ActionPacket(Action.GUARD_OFF, 0));
            guardSent = false;
        }
    }

    /** Dodge direction from whichever movement keys apply right now (fly keys while flying). */
    private static int dodgeArg(Minecraft mc) {
        boolean fly = ClientCombatData.flying;
        boolean f = fly ? XenoKeys.FLY_FORWARD.isDown() : mc.options.keyUp.isDown();
        boolean b = fly ? XenoKeys.FLY_BACKWARD.isDown() : mc.options.keyDown.isDown();
        boolean l = fly ? XenoKeys.FLY_LEFT.isDown() : mc.options.keyLeft.isDown();
        boolean r = fly ? XenoKeys.FLY_RIGHT.isDown() : mc.options.keyRight.isDown();
        return Dodge.pack((f ? 1 : 0) - (b ? 1 : 0), (r ? 1 : 0) - (l ? 1 : 0));
    }

    // ------------------------------------------------------------------ camera (per frame)

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.level != null && !mc.isPaused()) {
            LockOnClient.aim(mc, mc.player, mc.getDeltaFrameTime());
        }
    }

    // ------------------------------------------------------------------ movement input

    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        Input in = e.getInput();
        if (ClientCombatData.isHitstunned() || ClientCombatData.flying) {
            // stunned: no control at all. flying: vanilla walking is replaced by ClientFlight.
            in.up = in.down = in.left = in.right = false;
            in.forwardImpulse = 0.0f;
            in.leftImpulse = 0.0f;
            in.jumping = false;
            in.shiftKeyDown = false;
        } else if (ClientCombatData.guarding) {
            in.forwardImpulse *= 0.4f;
            in.leftImpulse *= 0.4f;
            in.jumping = false;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientCombatData.reset();
        LockOnClient.reset(Minecraft.getInstance());
        guardSent = false;
    }

    private ClientEvents() {}
}
