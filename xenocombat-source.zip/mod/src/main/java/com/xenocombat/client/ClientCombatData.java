package com.xenocombat.client;

import com.xenocombat.network.SyncPacket;

/**
 * Client-side mirror of the local player's server-validated combat state. Purely informational:
 * it blocks input during hitstun and drives HUD/flight/camera. The server never reads it.
 * Timers are decremented locally each client tick between (infrequent) server syncs.
 */
public final class ClientCombatData {
    public static volatile int hitstun;
    public static volatile int vanishCooldown;
    public static volatile int dodgeCooldown;
    public static volatile int combo;
    public static volatile boolean flying;
    public static volatile boolean guarding;
    public static volatile boolean launched;
    /** Entity id of the lock-on target; -1 when none. Requested by the client, confirmed by the server. */
    public static volatile int lockTargetId = -1;

    public static void apply(SyncPacket p) {
        hitstun = p.hitstun();
        vanishCooldown = p.vanishCooldown();
        dodgeCooldown = p.dodgeCooldown();
        combo = p.combo();
        flying = p.flying();
        guarding = p.guarding();
        launched = p.launched();
        lockTargetId = p.lockTargetId();
    }

    public static void tick() {
        if (hitstun > 0) hitstun--;
        if (vanishCooldown > 0) vanishCooldown--;
        if (dodgeCooldown > 0) dodgeCooldown--;
    }

    public static boolean isHitstunned() {
        return hitstun > 0;
    }

    public static void reset() {
        hitstun = 0;
        vanishCooldown = 0;
        dodgeCooldown = 0;
        combo = 0;
        flying = false;
        guarding = false;
        launched = false;
        lockTargetId = -1;
    }

    private ClientCombatData() {}
}
