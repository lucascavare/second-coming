package com.xenocombat.core;

/** Discrete player inputs sent client -> server. The server decides everything; the client only requests. */
public enum Action {
    M1,
    GUARD_ON,
    GUARD_OFF,
    DODGE,          // arg = packed direction (see Dodge: -1..1 forward in bits 0-1, strafe in bits 2-3)
    VANISH,
    LOCK,           // arg = entity id of requested lock target, or -1 to release
    FLIGHT_TOGGLE;

    private static final Action[] VALUES = values();

    public static Action byOrdinal(int i) {
        return i >= 0 && i < VALUES.length ? VALUES[i] : null;
    }
}
