package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Directional dodge: a short burst of fast movement with a brief melee-hit immunity window.
 * No stamina: the only limit is a configurable cooldown. Works in the air (direction then follows the look vector).
 */
public final class Dodge {
    public static final int DURATION = 5;

    /** Unpack the client's request: forward in bits 0-1, strafe in bits 2-3, each stored as value+1 (0..2). */
    public static int pack(int forward, int strafe) {
        return (forward + 1) | ((strafe + 1) << 2);
    }

    public static int forwardOf(int packed) {
        return Math.max(-1, Math.min(1, (packed & 3) - 1));
    }

    public static int strafeOf(int packed) {
        return Math.max(-1, Math.min(1, ((packed >> 2) & 3) - 1));
    }

    /** Resolve a forward/strafe request into a world direction relative to where the fighter is facing. */
    public static Vec3 direction(LivingEntity e, int forward, int strafe, boolean airborneFlight) {
        Vec3 look = e.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        flat = flat.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : flat.normalize();
        Vec3 right = new Vec3(-flat.z, 0.0, flat.x);
        if (forward == 0 && strafe == 0) {
            forward = -1; // no direction held -> dodge straight back
        }
        Vec3 fwd = airborneFlight ? look.normalize() : flat;
        return fwd.scale(forward).add(right.scale(strafe));
    }

    public static boolean start(LivingEntity e, CombatState s, Vec3 dir) {
        if (!XenoConfig.ENABLE_DODGE.get() || s.dodgeCooldown > 0 || !s.canAct() || dir.lengthSqr() < 1.0E-6) {
            return false;
        }
        Vec3 d = dir.normalize();
        double perTick = XenoConfig.DODGE_DISTANCE.get() / DURATION;
        s.dodgeX = d.x * perTick;
        s.dodgeY = d.y * perTick;
        s.dodgeZ = d.z * perTick;
        s.dodgeTicks = DURATION;
        s.dodgeCooldown = XenoConfig.DODGE_COOLDOWN_TICKS.get();
        s.invuln = Math.max(s.invuln, XenoConfig.DODGE_INVULN_TICKS.get());
        s.guarding = false;
        s.lungeTicks = 0;
        s.dirty = true;
        Fx.dodge(e);
        return true;
    }

    /** Called once per tick while dodgeTicks > 0. */
    public static void tick(LivingEntity e, CombatState s) {
        s.dodgeTicks--;
        if (s.isStunned()) {
            s.dodgeTicks = 0;
            return;
        }
        Vec3 m = e.getDeltaMovement();
        double y = (s.flying || s.dodgeY != 0.0) ? s.dodgeY : m.y;
        e.setDeltaMovement(s.dodgeX, y, s.dodgeZ);
        e.hurtMarked = true;
        e.fallDistance = 0.0f;
        if (s.dodgeTicks <= 0) {
            e.setDeltaMovement(s.dodgeX * 0.2, e.getDeltaMovement().y * 0.5, s.dodgeZ * 0.2);
            e.hurtMarked = true;
        }
    }

    private Dodge() {}
}
