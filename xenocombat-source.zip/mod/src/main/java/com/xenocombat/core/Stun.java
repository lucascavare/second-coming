package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * Hitstun / launch / punish application and release.
 * Ordinary mobs are frozen by disabling their AI for the duration (restored afterwards).
 * The combat NPC and players are handled by their own tick/input code, which reads CombatState.
 */
public final class Stun {

    /** Apply (or extend) hitstun unless the victim is currently immune. Returns true if stun was applied. */
    public static boolean hitstun(LivingEntity victim, CombatState s, int ticks) {
        if (s.hitstunImmunity > 0 || s.stunChain >= CombatState.MAX_STUN_CHAIN_TICKS) {
            return false;
        }
        s.hitstun = Math.max(s.hitstun, ticks);
        s.lungeTicks = 0;
        s.dodgeTicks = 0;
        s.guarding = false;
        s.resetCombo();
        freeze(victim, s);
        s.dirty = true;
        return true;
    }

    /** Fifth-hit launch: knocks the victim away and up and stuns them for the airborne window. */
    public static void launch(LivingEntity victim, CombatState s, Vec3 horizontalDir, int stunTicks) {
        Vec3 motion = new Vec3(horizontalDir.x * XenoConfig.LAUNCH_HORIZONTAL.get(),
                XenoConfig.LAUNCH_VERTICAL.get(),
                horizontalDir.z * XenoConfig.LAUNCH_HORIZONTAL.get());
        victim.setDeltaMovement(motion);
        victim.setOnGround(false);
        victim.hasImpulse = true;
        victim.hurtMarked = true; // makes the server send the new velocity to clients (including the victim themself)
        s.launched = true;
        s.launchTicks = 0;
        hitstun(victim, s, stunTicks);
        s.dirty = true;
    }

    /** Short stun for an attacker whose swing was parried. */
    public static void punish(LivingEntity attacker, CombatState s, int ticks) {
        s.punish = Math.max(s.punish, ticks);
        s.lungeTicks = 0;
        s.dodgeTicks = 0;
        s.resetCombo();
        freeze(attacker, s);
        s.dirty = true;
    }

    /** Break out of all stun immediately (defensive Z-Vanish). Grants no immunity. */
    public static void clear(LivingEntity e, CombatState s) {
        s.hitstun = 0;
        s.punish = 0;
        s.stunChain = 0;
        s.launched = false;
        s.launchTicks = 0;
        release(e, s);
        s.dirty = true;
    }

    /**
     * Freezes an ordinary goal-based mob by disabling its MOVE/JUMP/LOOK goal flags (vanilla mechanism) instead of
     * NoAI, so launch velocity and gravity keep working. Brain-based mobs (piglins, villagers) are only partly
     * affected - documented limitation. Re-asserted every tick by hold().
     */
    public static void freeze(LivingEntity e, CombatState s) {
        if (e instanceof Mob m && !(e instanceof ICombatant) && !s.frozen) {
            m.goalSelector.disableControlFlag(Goal.Flag.MOVE);
            m.goalSelector.disableControlFlag(Goal.Flag.JUMP);
            m.goalSelector.disableControlFlag(Goal.Flag.LOOK);
            s.frozen = true;
        }
    }

    /** Per-tick upkeep while a mob is frozen: drop any path / pending movement the previous AI tick queued. */
    public static void hold(LivingEntity e, CombatState s) {
        if (s.frozen && e instanceof Mob m) {
            m.getNavigation().stop();
            m.setXxa(0.0f);
            m.setZza(0.0f);
            m.setSpeed(0.0f);
            m.setJumping(false);
        }
    }

    public static void release(LivingEntity e, CombatState s) {
        if (s.frozen && e instanceof Mob m) {
            m.goalSelector.enableControlFlag(Goal.Flag.MOVE);
            m.goalSelector.enableControlFlag(Goal.Flag.JUMP);
            m.goalSelector.enableControlFlag(Goal.Flag.LOOK);
            s.frozen = false;
        }
    }

    private Stun() {}
}
