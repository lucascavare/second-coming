package com.xenocombat.core;

import com.xenocombat.network.SyncPacket;
import com.xenocombat.network.XenoNetwork;
import net.minecraft.server.level.ServerPlayer;

/**
 * Sends a player's combat state to that player only when it has actually diverged from what the client already
 * predicts (the client counts timers down locally). Idle players cost nothing; active ones send a handful of
 * packets per second at most.
 */
public final class SyncManager {
    private static final int RESYNC_INTERVAL = 40;

    public static void tick(ServerPlayer p, CombatState s, long now) {
        long dt = s.lastSyncTick < 0 ? 0 : now - s.lastSyncTick;
        boolean changed = s.lastSyncTick < 0
                || off(s.hitstun, s.lastSyncHitstun, dt)
                || off(s.vanishCooldown, s.lastSyncVanish, dt)
                || off(s.dodgeCooldown, s.lastSyncDodge, dt)
                || s.combo != s.lastSyncCombo
                || s.flying != s.lastSyncFlying
                || s.guarding != s.lastSyncGuarding
                || s.launched != s.lastSyncLaunched
                || s.lockTargetId != s.lastSyncLock;
        boolean active = s.hitstun > 0 || s.vanishCooldown > 0 || s.dodgeCooldown > 0;
        if (!changed && !(active && dt >= RESYNC_INTERVAL)) {
            s.dirty = false;
            return;
        }
        XenoNetwork.sendTo(p, new SyncPacket(s.hitstun, s.vanishCooldown, s.dodgeCooldown, s.combo,
                s.flying, s.guarding, s.launched, s.lockTargetId));
        s.lastSyncTick = now;
        s.lastSyncHitstun = s.hitstun;
        s.lastSyncVanish = s.vanishCooldown;
        s.lastSyncDodge = s.dodgeCooldown;
        s.lastSyncCombo = s.combo;
        s.lastSyncFlying = s.flying;
        s.lastSyncGuarding = s.guarding;
        s.lastSyncLaunched = s.launched;
        s.lastSyncLock = s.lockTargetId;
        s.dirty = false;
    }

    /** Does the real value differ from what the client would predict after dt ticks of counting down? */
    private static boolean off(int actual, int lastSent, long dt) {
        int predicted = (int) Math.max(0, lastSent - dt);
        return Math.abs(actual - predicted) > 1;
    }

    /** Force the next tick to send everything (login, respawn, dimension change). */
    public static void invalidate(CombatState s) {
        s.lastSyncTick = -1;
    }

    private SyncManager() {}
}
