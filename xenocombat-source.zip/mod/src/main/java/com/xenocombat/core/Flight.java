package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * Server side of combat flight. NOT creative flight: it is a combat state (CombatState.flying) that
 *  - removes gravity and fall damage while active (except during hitstun, so launches still arc),
 *  - ends on landing, on death, or when toggled off,
 *  - keeps all combat actions available (M1, guard, parry, dodge, Z-Vanish), subject to the aerial toggle.
 * Player movement itself is computed client-side from the flight keybinds (ClientFlight) because vanilla player
 * positions are client-authoritative; the server keeps the state, gravity flag and anti-kick bookkeeping.
 * mayfly is raised only so the dedicated server does not kick the player for "floating"; creative-style
 * toggling of abilities.flying is cancelled both here and on the client.
 */
public final class Flight {
    private static final String MAYFLY_TAG = "xenocombat_mayfly";

    public static boolean start(LivingEntity e, CombatState s) {
        if (!XenoConfig.ENABLE_FLIGHT.get() || s.flying || !s.canAct()) {
            return false;
        }
        if (e instanceof ServerPlayer p) {
            if (p.isCreative() || p.isSpectator()) {
                p.displayClientMessage(Component.literal("Combat flight is for survival/adventure mode."), true);
                return false;
            }
            if (!p.getAbilities().mayfly) {
                p.getAbilities().mayfly = true;
                s.grantedMayfly = true;
                p.getPersistentData().putBoolean(MAYFLY_TAG, true); // survives a crash so login can undo it
                p.onUpdateAbilities();
            }
        }
        s.flying = true;
        s.flyGrace = 15;
        e.setNoGravity(true);
        e.fallDistance = 0.0f;
        s.dirty = true;
        Fx.flightStart(e);
        return true;
    }

    public static void stop(LivingEntity e, CombatState s) {
        if (!s.flying) {
            return;
        }
        s.flying = false;
        if (s.hover <= 0) {
            e.setNoGravity(false);
        }
        revokeMayfly(e, s);
        s.dirty = true;
        Fx.flightStop(e);
    }

    public static void toggle(LivingEntity e, CombatState s) {
        if (s.flying) {
            stop(e, s);
        } else {
            start(e, s);
        }
    }

    /** Once per tick for any fighter with flying == true or hover > 0. */
    public static void tick(LivingEntity e, CombatState s) {
        if (s.flying) {
            e.fallDistance = 0.0f;
            boolean stunned = s.hitstun > 0 || s.punish > 0;
            e.setNoGravity(!stunned); // stunned flyers fall/arc normally, keeping launches readable
            if (e instanceof ServerPlayer p && p.getAbilities().flying) {
                p.getAbilities().flying = false; // cancel creative-style flight toggled by double-tap jump
                p.onUpdateAbilities();
            }
            if (s.flyGrace > 0) {
                s.flyGrace--;
            } else if (e.onGround() && !stunned && e instanceof ServerPlayer) {
                stop(e, s); // touching down ends flight
            }
        } else if (s.hover > 0) {
            s.hover--;
            e.fallDistance = 0.0f;
            e.setNoGravity(s.hover > 0);
            if (s.hover == 0) {
                e.setNoGravity(false);
            }
        }
    }

    public static void revokeMayfly(LivingEntity e, CombatState s) {
        if (s.grantedMayfly && e instanceof ServerPlayer p) {
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
                p.onUpdateAbilities();
            }
            p.getPersistentData().remove(MAYFLY_TAG);
            s.grantedMayfly = false;
        }
    }

    /** On login: undo a mayfly grant that was never revoked (server crash while flying). */
    public static void cleanStaleMayfly(ServerPlayer p) {
        if (p.getPersistentData().getBoolean(MAYFLY_TAG)) {
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().mayfly = false;
                p.getAbilities().flying = false;
                p.onUpdateAbilities();
            }
            p.getPersistentData().remove(MAYFLY_TAG);
        }
        p.setNoGravity(false);
    }

    private Flight() {}
}
