package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Z-Vanish. ONE implementation shared by players and the combat NPC. The 7 second cooldown lives in
 * CombatState.vanishCooldown on the server and is the only authority.
 *
 *  Defensive: fighter is stunned / was hit within the activation window -> breaks out of stun and reappears
 *             behind (or beside) the attacker, with a short melee invulnerability so the next hit whiffs.
 *  Offensive: fighter just launched a target (pursuit window) or has a locked target in range -> reappears
 *             behind/next to it so the combo can continue.
 *
 * Destinations must be free of blocks and reachable without crossing walls (no teleporting through terrain).
 */
public final class Vanish {
    public enum Result { NO_COOLDOWN, DISABLED, NO_TARGET, NO_SPACE, DEFENSIVE, OFFENSIVE }

    public static Result tryVanish(LivingEntity e, CombatState s, LivingEntity preferredTarget) {
        if (!XenoConfig.ENABLE_VANISH.get()) {
            return Result.DISABLED;
        }
        if (!s.vanishReady()) {
            return Result.NO_COOLDOWN;
        }
        boolean underAttack = s.isStunned() || s.sinceHit <= XenoConfig.VANISH_WINDOW_TICKS.get();
        return underAttack ? defensive(e, s) : offensive(e, s, preferredTarget);
    }

    // ------------------------------------------------------------------ defensive

    private static Result defensive(LivingEntity e, CombatState s) {
        LivingEntity attacker = Targeting.byId(e.level(), s.lastAttackerId);
        Vec3 dest;
        if (attacker != null && attacker.distanceToSqr(e) <= sq(XenoConfig.VANISH_MAX_DISTANCE.get())) {
            dest = findSpot(e, attacker, true);
        } else {
            attacker = null;
            dest = findEscapeSpot(e);
        }
        if (dest == null) {
            return Result.NO_SPACE;
        }
        Stun.clear(e, s);
        s.invuln = Math.max(s.invuln, 10);
        s.guarding = false;
        if (attacker != null) {
            CombatState a = StateManager.of(attacker);
            a.resetCombo();          // the attacker lost their target mid-combo
            a.dirty = true;
        }
        commit(e, s, dest, attacker);
        return Result.DEFENSIVE;
    }

    // ------------------------------------------------------------------ offensive

    private static Result offensive(LivingEntity e, CombatState s, LivingEntity preferred) {
        LivingEntity target = null;
        if (s.pursuitTicks > 0) {
            target = Targeting.byId(e.level(), s.pursuitTargetId);
        }
        if (target == null && preferred != null && preferred.isAlive()) {
            target = preferred;
        }
        if (target == null || !Targeting.isValidTarget(e, target)
                || target.distanceToSqr(e) > sq(XenoConfig.VANISH_MAX_DISTANCE.get())) {
            return Result.NO_TARGET;
        }
        Vec3 dest = findSpot(e, target, false);
        if (dest == null) {
            return Result.NO_SPACE;
        }
        s.pursuitTicks = 0;
        s.pursuitTargetId = -1;
        s.resetCombo(); // a fresh chain starts from the new position
        commit(e, s, dest, target);
        if (!(e instanceof Mob)) {
            s.lockTargetId = target.getId();
        }
        return Result.OFFENSIVE;
    }

    // ------------------------------------------------------------------ shared

    private static void commit(LivingEntity e, CombatState s, Vec3 dest, LivingEntity faceThis) {
        Vec3 from = e.position();
        float yaw = e.getYRot();
        float pitch = e.getXRot();
        if (faceThis != null) {
            Vec3 d = faceThis.getBoundingBox().getCenter().subtract(dest.add(0.0, e.getEyeHeight(), 0.0));
            yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
            pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
        }
        teleport(e, dest, yaw, pitch);
        s.vanishCooldown = XenoConfig.VANISH_COOLDOWN_TICKS.get();
        s.vanishedAt = e.level().getGameTime();
        s.hover = 12;
        s.attackCooldown = 0;   // free to strike on arrival
        s.lungeTicks = 0;
        s.dodgeTicks = 0;
        s.dirty = true;
        Fx.vanish(e, from, dest);
    }

    private static void teleport(LivingEntity e, Vec3 dest, float yaw, float pitch) {
        if (e instanceof ServerPlayer sp) {
            sp.connection.teleport(dest.x, dest.y, dest.z, yaw, pitch);
        } else {
            e.moveTo(dest.x, dest.y, dest.z, yaw, pitch);
            e.setYHeadRot(yaw);
            e.setYBodyRot(yaw);
            if (e instanceof Mob m) {
                m.getNavigation().stop();
            }
        }
        e.setDeltaMovement(Vec3.ZERO);
        e.hurtMarked = true;
        e.fallDistance = 0.0f;
    }

    /**
     * Pick an arrival point around 'target'. Offensive: behind first (relative to the target's facing), then the
     * sides, then front. Defensive: same but slightly farther so the arrival isn't inside the attacker's reach.
     */
    private static Vec3 findSpot(LivingEntity mover, LivingEntity target, boolean defensive) {
        double d = XenoConfig.VANISH_BEHIND_DISTANCE.get() + (defensive ? 1.2 : 0.0);
        Vec3 look = target.getLookAngle();
        Vec3 f = new Vec3(look.x, 0.0, look.z);
        f = f.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : f.normalize();
        Vec3 r = new Vec3(-f.z, 0.0, f.x);
        Vec3[] offsets = {
                f.scale(-d),
                f.scale(-d * 0.7).add(r.scale(d * 0.7)),
                f.scale(-d * 0.7).add(r.scale(-d * 0.7)),
                r.scale(d), r.scale(-d),
                f.scale(d),
        };
        Vec3 base = target.position();
        for (Vec3 off : offsets) {
            Vec3 spot = freeSpot(mover, base.add(off));
            if (spot != null && clearPath(mover, target, spot)) {
                return spot;
            }
        }
        return null;
    }

    private static Vec3 findEscapeSpot(LivingEntity e) {
        Vec3 look = e.getLookAngle();
        Vec3 back = new Vec3(-look.x, 0.0, -look.z);
        back = back.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, -1.0) : back.normalize();
        for (double dist : new double[] {6.0, 4.0, 2.5}) {
            Vec3 spot = freeSpot(e, e.position().add(back.scale(dist)));
            if (spot != null && clearPath(e, null, spot)) {
                return spot;
            }
        }
        return null;
    }

    /** Nearest unobstructed position at (or slightly above/below) the wanted spot. */
    private static Vec3 freeSpot(LivingEntity e, Vec3 want) {
        for (double dy : new double[] {0.0, 1.0, -1.0, 2.0}) {
            Vec3 p = want.add(0.0, dy, 0.0);
            if (e.level().noCollision(e, e.getBoundingBox().move(p.subtract(e.position())))) {
                return p;
            }
        }
        return null;
    }

    /** No terrain between the mover's current eye position and the arrival point (no teleporting through walls). */
    private static boolean clearPath(LivingEntity mover, LivingEntity target, Vec3 spot) {
        Vec3 from = mover.getEyePosition();
        Vec3 to = spot.add(0.0, mover.getEyeHeight(), 0.0);
        if (mover.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mover)).getType() != HitResult.Type.MISS) {
            return false;
        }
        if (target != null) {
            Vec3 tc = target.getBoundingBox().getCenter();
            return mover.level().clip(new ClipContext(to, tc, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mover)).getType() == HitResult.Type.MISS;
        }
        return true;
    }

    private static double sq(double v) {
        return v * v;
    }

    private Vanish() {}
}
