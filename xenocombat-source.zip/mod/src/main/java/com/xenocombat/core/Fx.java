package com.xenocombat.core;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Server-driven feedback using vanilla particles and sounds only (no custom assets needed). */
public final class Fx {

    private static void sound(Entity at, SoundEvent s, float vol, float pitch) {
        at.level().playSound(null, at.getX(), at.getY(), at.getZ(), s, SoundSource.PLAYERS, vol, pitch);
    }

    private static ServerLevel sl(Entity e) {
        return e.level() instanceof ServerLevel s ? s : null;
    }

    public static void hit(Entity victim, int comboIndex) {
        ServerLevel l = sl(victim);
        if (l == null) return;
        Vec3 c = victim.getBoundingBox().getCenter();
        l.sendParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 6 + comboIndex * 2, 0.25, 0.3, 0.25, 0.25);
        sound(victim, SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 0.9f + comboIndex * 0.08f); // pitch climbs with the combo
    }

    public static void launch(Entity victim) {
        ServerLevel l = sl(victim);
        if (l == null) return;
        Vec3 c = victim.getBoundingBox().getCenter();
        l.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        l.sendParticles(ParticleTypes.CLOUD, c.x, c.y - 0.5, c.z, 14, 0.3, 0.1, 0.3, 0.15);
        sound(victim, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.2f, 0.7f);
    }

    public static void parry(Entity defender) {
        ServerLevel l = sl(defender);
        if (l == null) return;
        Vec3 c = defender.getBoundingBox().getCenter().add(defender.getLookAngle().scale(0.8));
        l.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        l.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 18, 0.3, 0.3, 0.3, 0.4);
        sound(defender, SoundEvents.ANVIL_LAND, 0.8f, 1.7f);
        sound(defender, SoundEvents.SHIELD_BLOCK, 1.0f, 1.4f);
    }

    public static void guard(Entity defender) {
        ServerLevel l = sl(defender);
        if (l == null) return;
        Vec3 c = defender.getBoundingBox().getCenter().add(defender.getLookAngle().scale(0.7));
        l.sendParticles(ParticleTypes.ENCHANTED_HIT, c.x, c.y, c.z, 8, 0.25, 0.25, 0.25, 0.1);
        sound(defender, SoundEvents.SHIELD_BLOCK, 0.9f, 0.9f);
    }

    public static void guardBreak(Entity defender) {
        sound(defender, SoundEvents.SHIELD_BREAK, 1.0f, 1.0f);
    }

    public static void vanish(Entity e, Vec3 from, Vec3 to) {
        ServerLevel l = sl(e);
        if (l == null) return;
        l.sendParticles(ParticleTypes.SMOKE, from.x, from.y + 1.0, from.z, 20, 0.3, 0.6, 0.3, 0.02);
        l.sendParticles(ParticleTypes.REVERSE_PORTAL, to.x, to.y + 1.0, to.z, 24, 0.3, 0.6, 0.3, 0.1);
        l.playSound(null, from.x, from.y, from.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8f, 1.5f);
        l.playSound(null, to.x, to.y, to.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8f, 1.9f);
    }

    public static void dodge(Entity e) {
        ServerLevel l = sl(e);
        if (l == null) return;
        l.sendParticles(ParticleTypes.CLOUD, e.getX(), e.getY() + 0.5, e.getZ(), 10, 0.3, 0.4, 0.3, 0.05);
        sound(e, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7f, 1.6f);
    }

    public static void lunge(Entity e) {
        sound(e, SoundEvents.PLAYER_ATTACK_SWEEP, 0.6f, 1.2f);
    }

    public static void flightStart(Entity e) {
        ServerLevel l = sl(e);
        if (l == null) return;
        l.sendParticles(ParticleTypes.CLOUD, e.getX(), e.getY(), e.getZ(), 12, 0.4, 0.1, 0.4, 0.1);
        sound(e, SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.6f, 1.4f);
    }

    public static void flightStop(Entity e) {
        sound(e, SoundEvents.FIREWORK_ROCKET_BLAST, 0.4f, 0.8f);
    }

    private Fx() {}
}
