package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Target validity, candidate scoring and melee target lookup. Shared by client (lock-on picking) and server (validation). */
public final class Targeting {

    /** Config filters + sanity. Combat NPCs are always valid targets for players. */
    public static boolean isValidTarget(LivingEntity self, Entity e) {
        if (!(e instanceof LivingEntity t) || t == self || !t.isAlive() || t.isRemoved() || t.isSpectator()) {
            return false;
        }
        if (t instanceof ICombatant) {
            return true;
        }
        if (t instanceof Player) {
            return XenoConfig.TARGET_PLAYERS.get();
        }
        if (t instanceof Enemy) {
            return XenoConfig.TARGET_HOSTILE.get();
        }
        if (t instanceof Mob) {
            return XenoConfig.TARGET_PASSIVE.get();
        }
        return XenoConfig.TARGET_OTHER.get();
    }

    public static boolean hasLineOfSight(LivingEntity self, Entity target) {
        return self.hasLineOfSight(target);
    }

    /** Shortest distance from the attacker's eye to the target's hitbox. */
    public static double hitboxDistance(LivingEntity attacker, Entity target) {
        Vec3 eye = attacker.getEyePosition();
        AABB bb = target.getBoundingBox();
        double x = Math.max(bb.minX, Math.min(eye.x, bb.maxX));
        double y = Math.max(bb.minY, Math.min(eye.y, bb.maxY));
        double z = Math.max(bb.minZ, Math.min(eye.z, bb.maxZ));
        return eye.distanceTo(new Vec3(x, y, z));
    }

    /** Angle in degrees between viewer's look direction and the direction to the target's center. */
    public static double angleTo(LivingEntity viewer, Entity target) {
        Vec3 look = viewer.getLookAngle();
        Vec3 to = target.getBoundingBox().getCenter().subtract(viewer.getEyePosition());
        if (to.lengthSqr() < 1.0E-6) {
            return 0.0;
        }
        double dot = Math.max(-1.0, Math.min(1.0, look.dot(to.normalize())));
        return Math.toDegrees(Math.acos(dot));
    }

    /**
     * Best lock-on candidate: small angle to the crosshair first, distance second.
     * Single AABB query, no world-wide scans. Works identically while flying.
     */
    public static LivingEntity findLockCandidate(LivingEntity viewer, double range, boolean requireLos, LivingEntity exclude) {
        AABB box = viewer.getBoundingBox().inflate(range);
        List<LivingEntity> list = viewer.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> e != exclude && isValidTarget(viewer, e) && viewer.distanceToSqr(e) <= range * range);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double score = angleTo(viewer, e) + Math.sqrt(viewer.distanceToSqr(e)) * 0.35;
            if (score < bestScore && (!requireLos || hasLineOfSight(viewer, e))) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    /** Target an M1 swing would hit: the locked target if inside reach, else the closest valid entity in a forward cone. */
    public static LivingEntity findMeleeTarget(LivingEntity attacker, LivingEntity locked, double reach) {
        if (locked != null && isValidTarget(attacker, locked) && hitboxDistance(attacker, locked) <= reach) {
            return locked;
        }
        AABB box = attacker.getBoundingBox().inflate(reach + 1.0);
        List<LivingEntity> list = attacker.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> isValidTarget(attacker, e) && hitboxDistance(attacker, e) <= reach);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double angle = angleTo(attacker, e);
            if (angle > 65.0) {
                continue;
            }
            double score = angle + hitboxDistance(attacker, e) * 4.0;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    public static LivingEntity byId(Level level, int id) {
        if (id < 0) {
            return null;
        }
        Entity e = level.getEntity(id);
        return e instanceof LivingEntity le && le.isAlive() ? le : null;
    }

    private Targeting() {}
}
