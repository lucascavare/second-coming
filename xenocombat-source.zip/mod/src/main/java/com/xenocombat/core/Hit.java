package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Resolves one M1 hit from any attacker (player or NPC) on any victim, in strict priority order:
 * dodge/vanish invulnerability -> perfect parry -> guard -> damage + hitstun/launch.
 * Server thread only.
 */
public final class Hit {
    public enum Result { HIT, GUARDED, PARRIED, DODGED }

    /** True while we are inside our own hurt() call so the vanilla-damage event handlers ignore it. */
    public static boolean inCustomHit;

    public static Result resolve(LivingEntity attacker, LivingEntity victim, int index, float baseDamage) {
        CombatState a = StateManager.of(attacker);
        CombatState v = StateManager.of(victim);
        float damage = index >= CombatState.COMBO_LENGTH ? baseDamage * XenoConfig.FINISHER_MULTIPLIER.get().floatValue() : baseDamage;

        if (v.invuln > 0) {
            a.resetCombo();
            a.dirty = true;
            return Result.DODGED;
        }

        boolean frontal = isFrontal(victim, attacker);
        if (XenoConfig.ENABLE_PARRY.get() && v.guarding && frontal && v.guardTicks <= XenoConfig.PARRY_WINDOW_TICKS.get()) {
            applyParry(attacker, victim, a, v);
            return Result.PARRIED;
        }
        if (v.guarding && frontal) {
            applyGuard(attacker, victim, a, v, index, damage);
            return Result.GUARDED;
        }

        // ---- clean hit
        damage(attacker, victim, damage);
        v.sinceHit = 0;
        v.lastAttackerId = attacker.getId();
        v.resetCombo();
        v.dirty = true;

        Vec3 dir = awayFrom(attacker, victim);
        if (victim.isAlive()) {
            if (index >= CombatState.COMBO_LENGTH) {
                if (v.hitstunImmunity <= 0 && v.stunChain < CombatState.MAX_STUN_CHAIN_TICKS) {
                    Stun.launch(victim, v, dir, XenoConfig.FINISHER_STUN_TICKS.get());
                    Fx.launch(victim);
                } else {
                    push(victim, dir, 0.5, 0.15); // immune: damage and a shove only, no re-launch (anti stun-lock)
                }
            } else if (Stun.hitstun(victim, v, XenoConfig.HITSTUN_TICKS.get())) {
                push(victim, dir, 0.12, victim.onGround() ? 0.0 : 0.04);
            } else {
                push(victim, dir, 0.2, 0.0);
            }
        }
        Fx.hit(victim, index);

        // ---- attacker bookkeeping
        if (index >= CombatState.COMBO_LENGTH) {
            a.resetCombo();
            if (victim.isAlive()) {
                a.pursuitTargetId = victim.getId();
                a.pursuitTicks = 60; // window in which an offensive Z-Vanish may chase the launched target
            }
        } else {
            a.combo = index;
            a.comboTimer = XenoConfig.COMBO_WINDOW_TICKS.get();
        }
        a.dirty = true;
        return Result.HIT;
    }

    // ------------------------------------------------------------------ defensive outcomes

    /** Perfect parry: negate the attack, break the attacker's combo, leave them punishable. Also used for vanilla melee. */
    public static void applyParry(LivingEntity attacker, LivingEntity victim, CombatState a, CombatState v) {
        Stun.punish(attacker, a, XenoConfig.PARRY_PUNISH_TICKS.get());
        v.parriedAt = victim.level().getGameTime();
        v.invuln = Math.max(v.invuln, 6);
        v.sinceHit = 1000;
        Vec3 away = awayFrom(victim, attacker);
        push(attacker, away, 0.35, 0.0);
        Fx.parry(victim);
        a.dirty = true;
        v.dirty = true;
    }

    private static void applyGuard(LivingEntity attacker, LivingEntity victim, CombatState a, CombatState v, int index, float damage) {
        float reduced = damage * XenoConfig.GUARD_DAMAGE_MULTIPLIER.get().floatValue();
        if (reduced > 0.0f) {
            damage(attacker, victim, reduced);
        }
        Vec3 dir = awayFrom(attacker, victim);
        if (index >= CombatState.COMBO_LENGTH) {
            // the finisher breaks the guard and leaves the defender briefly open (no launch)
            v.guarding = false;
            v.guardLock = 30;
            Fx.guardBreak(victim);
            Stun.hitstun(victim, v, 10);
            push(victim, dir, 0.8, 0.1);
            a.resetCombo();
        } else {
            Fx.guard(victim);
            push(victim, dir, 0.15, 0.0);
            a.combo = index;
            a.comboTimer = XenoConfig.COMBO_WINDOW_TICKS.get();
        }
        v.dirty = true;
        a.dirty = true;
    }

    // ------------------------------------------------------------------ helpers

    public static boolean damage(LivingEntity attacker, LivingEntity victim, float amount) {
        DamageSource src = attacker instanceof Player p
                ? attacker.damageSources().playerAttack(p)
                : attacker.damageSources().mobAttack(attacker);
        inCustomHit = true;
        try {
            victim.invulnerableTime = 0; // vanilla i-frames must not swallow rapid combo hits
            return victim.hurt(src, amount);
        } finally {
            inCustomHit = false;
        }
    }

    public static void push(LivingEntity e, Vec3 dir, double horizontal, double vertical) {
        Vec3 m = e.getDeltaMovement();
        e.setDeltaMovement(dir.x * horizontal, vertical > 0.0 ? Math.max(m.y, vertical) : m.y, dir.z * horizontal);
        e.hurtMarked = true;
    }

    /** Horizontal unit vector pointing from 'from' toward 'to'. Falls back to from's facing when they overlap. */
    public static Vec3 awayFrom(LivingEntity from, LivingEntity to) {
        Vec3 d = new Vec3(to.getX() - from.getX(), 0.0, to.getZ() - from.getZ());
        if (d.lengthSqr() < 1.0E-6) {
            Vec3 look = from.getLookAngle();
            d = new Vec3(look.x, 0.0, look.z);
            if (d.lengthSqr() < 1.0E-6) {
                return new Vec3(0.0, 0.0, 1.0);
            }
        }
        return d.normalize();
    }

    /** Is 'attacker' inside the defender's frontal guard arc? */
    public static boolean isFrontal(LivingEntity defender, LivingEntity attacker) {
        Vec3 facing = defender.getViewVector(1.0f);
        facing = new Vec3(facing.x, 0.0, facing.z);
        Vec3 to = new Vec3(attacker.getX() - defender.getX(), 0.0, attacker.getZ() - defender.getZ());
        if (facing.lengthSqr() < 1.0E-6 || to.lengthSqr() < 1.0E-6) {
            return true;
        }
        double dot = Math.max(-1.0, Math.min(1.0, facing.normalize().dot(to.normalize())));
        return Math.toDegrees(Math.acos(dot)) <= XenoConfig.GUARD_ARC_DEGREES.get() / 2.0;
    }

    private Hit() {}
}
