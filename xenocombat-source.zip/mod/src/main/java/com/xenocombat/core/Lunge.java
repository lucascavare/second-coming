package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Attack lunge: when an M1 is pressed with nobody in reach, the attacker rushes the locked target and
 * swings on arrival. Re-aims every tick (tracks moving targets), works in the air, and ends the moment
 * a wall blocks the path, the target is lost, or the attacker is stunned. Movement itself is done by
 * normal entity physics, so a lunge can never pass through blocks.
 */
public final class Lunge {

    public static void start(LivingEntity attacker, CombatState s, LivingEntity target) {
        s.lungeTargetId = target.getId();
        s.lungeTicks = (int) Math.ceil(XenoConfig.LUNGE_RANGE.get() / XenoConfig.LUNGE_SPEED.get()) + 4;
        s.dirty = true;
        Fx.lunge(attacker);
    }

    /** Called once per server tick while lungeTicks > 0. */
    public static void tick(LivingEntity attacker, CombatState s) {
        LivingEntity target = Targeting.byId(attacker.level(), s.lungeTargetId);
        s.lungeTicks--;
        if (target == null || s.isStunned() || !Targeting.isValidTarget(attacker, target)) {
            end(attacker, s);
            return;
        }
        double reach = XenoConfig.M1_REACH.get();
        double dist = Targeting.hitboxDistance(attacker, target);
        if (dist <= reach * 0.9) {
            end(attacker, s);
            s.attackCooldown = 0;
            ComboManager.swing(attacker, s, target); // arrive and strike
            return;
        }
        Vec3 from = attacker.getBoundingBox().getCenter();
        Vec3 to = target.getBoundingBox().getCenter();
        Vec3 dir = to.subtract(from).normalize();
        double step = Math.max(0.15, Math.min(XenoConfig.LUNGE_SPEED.get(), dist - reach * 0.8));
        Vec3 motion = dir.scale(step);
        AABB moved = attacker.getBoundingBox().move(motion);
        if (!attacker.level().noCollision(attacker, moved)) {
            end(attacker, s); // wall or ceiling in the way
            return;
        }
        attacker.setDeltaMovement(motion);
        attacker.hurtMarked = true;
        attacker.fallDistance = 0.0f;
        if (s.lungeTicks <= 0) {
            end(attacker, s);
        }
    }

    public static void end(LivingEntity attacker, CombatState s) {
        if (s.lungeTicks > 0 || s.lungeTargetId != -1) {
            Vec3 m = attacker.getDeltaMovement();
            attacker.setDeltaMovement(m.scale(0.25)); // bleed off speed so the attacker doesn't overshoot
            attacker.hurtMarked = true;
        }
        s.lungeTicks = 0;
        s.lungeTargetId = -1;
        s.dirty = true;
    }

    private Lunge() {}
}
