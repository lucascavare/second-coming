package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.LivingEntity;

/**
 * Guard (hold) with a timing-based perfect parry. The parry window is NOT a separate input: it is simply the first
 * parryWindowTicks after guard is raised (see Hit.resolve / CombatEvents). A fighter that holds guard permanently
 * therefore gets normal guard only; to parry they must raise guard shortly before the hit lands.
 */
public final class Guard {

    public static boolean raise(LivingEntity e, CombatState s) {
        if (s.guarding || s.guardLock > 0 || !s.canAct() || s.dodgeTicks > 0) {
            return false;
        }
        s.guarding = true;
        s.guardTicks = 0;
        s.dirty = true;
        return true;
    }

    public static void lower(LivingEntity e, CombatState s) {
        if (!s.guarding) {
            return;
        }
        s.guarding = false;
        s.guardLock = XenoConfig.GUARD_BREAK_COOLDOWN_TICKS.get(); // anti parry-spam
        s.dirty = true;
    }

    /** True when a hit arriving right now would be a perfect parry. */
    public static boolean inParryWindow(CombatState s) {
        return XenoConfig.ENABLE_PARRY.get() && s.guarding && s.guardTicks <= XenoConfig.PARRY_WINDOW_TICKS.get();
    }

    private Guard() {}
}
