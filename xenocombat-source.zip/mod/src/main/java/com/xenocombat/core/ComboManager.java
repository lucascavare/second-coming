package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * The 5-hit M1 chain. Used identically by players (via ServerActions) and the combat NPC (via its AI).
 * Vanilla attack cooldown is bypassed entirely: timing is governed by CombatState.attackCooldown.
 */
public final class ComboManager {

    /**
     * Attempt one M1. If nothing is in reach but a valid locked target is within lunge range, the attacker
     * lunges and the swing happens automatically on arrival. Returns true if a swing or lunge started.
     */
    public static boolean tryM1(LivingEntity attacker, LivingEntity locked) {
        CombatState s = StateManager.of(attacker);
        if (s.attackCooldown > 0 || !s.canAct()) {
            return false;
        }
        LivingEntity target = Targeting.findMeleeTarget(attacker, locked, XenoConfig.M1_REACH.get());
        if (target != null) {
            swing(attacker, s, target);
            return true;
        }
        if (XenoConfig.ENABLE_LUNGE.get() && locked != null && Targeting.isValidTarget(attacker, locked)
                && Targeting.hitboxDistance(attacker, locked) <= XenoConfig.LUNGE_RANGE.get()
                && (!XenoConfig.LOCK_ON_LOS.get() || attacker.hasLineOfSight(locked))) {
            s.attackCooldown = XenoConfig.M1_COOLDOWN_TICKS.get();
            Lunge.start(attacker, s, locked);
            return true;
        }
        // whiff: the swing animation plays, the chain is not advanced
        s.attackCooldown = XenoConfig.M1_COOLDOWN_TICKS.get();
        attacker.swing(InteractionHand.MAIN_HAND, true);
        return false;
    }

    /**
     * Perform the next hit of the chain on a target that is already in reach and report what happened.
     * The combat NPC's brain handles its own (rate-limited) facing; other mobs get snapped to face the target.
     */
    public static Hit.Result swing(LivingEntity attacker, CombatState s, LivingEntity target) {
        int index = Math.min(s.combo + 1, CombatState.COMBO_LENGTH);
        s.attackCooldown = XenoConfig.M1_COOLDOWN_TICKS.get();
        if (!(attacker instanceof Player) && !(attacker instanceof ICombatant)) {
            faceTarget(attacker, target);
        }
        attacker.swing(InteractionHand.MAIN_HAND, true);
        return Hit.resolve(attacker, target, index, baseDamage(attacker));
    }

    public static float baseDamage(LivingEntity attacker) {
        if (attacker instanceof ICombatant c) {
            return c.m1Damage();
        }
        // weapon bonus on top of the configured base (bare hands: attribute is 1.0 -> no bonus)
        double bonus = Math.max(0.0, attacker.getAttributeValue(Attributes.ATTACK_DAMAGE) - 1.0);
        return (float) (XenoConfig.M1_DAMAGE.get() + bonus);
    }

    /** Snap a non-player attacker's body and head toward the target. Players' cameras are client-controlled. */
    public static void faceTarget(LivingEntity e, LivingEntity target) {
        double dx = target.getX() - e.getX();
        double dz = target.getZ() - e.getZ();
        double dy = target.getEyeY() - e.getEyeY();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        e.setYRot(yaw);
        e.setXRot(pitch);
        e.setYHeadRot(yaw);
        e.setYBodyRot(yaw);
    }

    private ComboManager() {}
}
