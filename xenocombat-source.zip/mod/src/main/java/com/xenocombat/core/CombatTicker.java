package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.world.entity.LivingEntity;

/**
 * Advances one fighter's timers by one tick. Called once per tick for: players (PlayerTickEvent), ordinary mobs that
 * have taken part in combat (server tick, tracked set only) and the combat NPC (its own tick). Order matters:
 * movement-producing states (lunge, dodge) run before timers expire so their last tick still applies.
 */
public final class CombatTicker {

    public static void tick(LivingEntity e, CombatState s) {
        // ---- movement-producing states
        if (s.lungeTicks > 0) {
            Lunge.tick(e, s);
        }
        if (s.dodgeTicks > 0) {
            Dodge.tick(e, s);
        }

        // ---- plain timers
        if (s.attackCooldown > 0) s.attackCooldown--;
        if (s.vanishCooldown > 0) s.vanishCooldown--;
        if (s.dodgeCooldown > 0) s.dodgeCooldown--;
        if (s.guardLock > 0) s.guardLock--;
        if (s.invuln > 0) s.invuln--;
        if (s.hitstunImmunity > 0) s.hitstunImmunity--;
        if (s.sinceHit < 1000) s.sinceHit++;
        if (s.guarding) s.guardTicks++;
        if (s.comboTimer > 0 && --s.comboTimer == 0) {
            s.combo = 0;
            s.dirty = true;
        }
        if (s.pursuitTicks > 0 && --s.pursuitTicks == 0) {
            s.pursuitTargetId = -1;
        }

        // ---- stun
        if (s.hitstun > 0 || s.punish > 0) {
            if (s.hitstun > 0) s.hitstun--;
            if (s.punish > 0) s.punish--;
            s.stunChain++;
            if (s.stunChain >= CombatState.MAX_STUN_CHAIN_TICKS) {
                // hard cap: no matter how many hits land, a continuous stun can't outlast this
                s.hitstun = 0;
                s.punish = 0;
            }
            Stun.hold(e, s);
        }
        if (s.hitstun == 0 && s.punish == 0) {
            if (s.stunChain > 0 || s.frozen || s.launched) {
                endStun(e, s);
            }
        }
        if (s.launched) {
            s.launchTicks++;
        }

        // ---- flight / hover
        if (s.flying || s.hover > 0) {
            Flight.tick(e, s);
        }

        // guard is meaningless while stunned
        if (s.guarding && s.isStunned()) {
            s.guarding = false;
        }
    }

    /** Stun finished (naturally, via the cap, or via vanish): release the victim and grant anti stun-lock immunity. */
    private static void endStun(LivingEntity e, CombatState s) {
        boolean wasLaunched = s.launched;
        boolean wasStunned = s.stunChain > 0;
        s.stunChain = 0;
        s.launched = false;
        s.launchTicks = 0;
        Stun.release(e, s);
        if (wasStunned) {
            s.hitstunImmunity = Math.max(s.hitstunImmunity, wasLaunched
                    ? XenoConfig.HITSTUN_IMMUNITY_TICKS.get()
                    : XenoConfig.HITSTUN_IMMUNITY_TICKS.get() / 3);
        }
        s.dirty = true;
    }

    private CombatTicker() {}
}
