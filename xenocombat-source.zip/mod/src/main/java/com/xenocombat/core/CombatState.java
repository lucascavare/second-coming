package com.xenocombat.core;

/**
 * Server-side combat state for ONE fighter (player, combat NPC, or any mob that gets hit).
 * Everything is tick-based. The same class is used by players and the NPC so both obey identical rules.
 * Nothing in here is ever read from a client.
 */
public final class CombatState {
    /** Hard anti stun-lock backstop: a victim cannot stay stunned longer than this in one chain. */
    public static final int MAX_STUN_CHAIN_TICKS = 100;
    public static final int COMBO_LENGTH = 5;

    // ---- attacker side
    public int combo;                 // hits already landed in the current chain (0..4); next swing is combo+1
    public int comboTimer;            // ticks left to continue the chain
    public int attackCooldown;        // ticks until the next M1 is allowed
    public int pursuitTargetId = -1;  // entity this fighter just launched (offensive vanish target)
    public int pursuitTicks;          // ticks left in which that pursuit is valid
    public int punish;                // ticks this fighter is stunned after being parried

    // ---- victim side
    public int hitstun;               // ticks of hitstun left
    public int stunChain;             // ticks spent continuously stunned (anti stun-lock)
    public int hitstunImmunity;       // ticks during which new hits cannot (re)apply hitstun
    public boolean launched;          // true from fifth-hit launch until landing/stun end
    public int launchTicks;
    public int sinceHit = 1000;       // ticks since this fighter last took a hit
    public int lastAttackerId = -1;
    public boolean frozen;            // for ordinary mobs: movement/look/jump goals disabled by us while stunned

    // ---- defense
    public boolean guarding;
    public int guardTicks;            // ticks since guard was raised (parry window counts from here)
    public int guardLock;             // ticks until guard can be raised again
    public long parriedAt = -1000;    // game time this fighter last landed a perfect parry (visible to AI as a state)
    public int invuln;                // melee-hit immunity ticks (dodge / vanish)
    public int dodgeCooldown;
    public int dodgeTicks;            // ticks of dodge movement left
    public double dodgeX, dodgeZ, dodgeY; // dodge velocity per tick

    // ---- vanish
    public int vanishCooldown;        // authoritative 7s cooldown lives here (server)

    // ---- lunge
    public int lungeTicks;
    public int lungeTargetId = -1;

    public int hover;                 // ticks of no-gravity after a vanish so the arrival isn't a free fall
    public long vanishedAt = -1000;   // game time of the last vanish; visible to observers (NPC perception)

    // ---- lock-on / flight
    public int lockTargetId = -1;
    public boolean flying;
    public int flyGrace;              // ticks after takeoff during which touching the ground doesn't end flight
    public boolean grantedMayfly;     // we raised abilities.mayfly (to stop the vanilla floating kick) and must revoke it

    // ---- sync bookkeeping (server -> owning client)
    public boolean dirty;
    public long lastSyncTick = -1;
    public int lastSyncHitstun, lastSyncVanish, lastSyncDodge, lastSyncCombo, lastSyncLock = -2;
    public boolean lastSyncFlying, lastSyncGuarding, lastSyncLaunched;

    public boolean isStunned() {
        return hitstun > 0 || punish > 0;
    }

    public boolean canAct() {
        return !isStunned() && lungeTicks <= 0;
    }

    public boolean vanishReady() {
        return vanishCooldown <= 0;
    }

    public void resetCombo() {
        combo = 0;
        comboTimer = 0;
    }

    public void clearForDeath() {
        combo = comboTimer = attackCooldown = punish = hitstun = stunChain = hitstunImmunity = 0;
        launched = false;
        launchTicks = 0;
        guarding = false;
        guardTicks = guardLock = invuln = dodgeTicks = lungeTicks = hover = flyGrace = 0;
        lockTargetId = -1;
        pursuitTargetId = -1;
        pursuitTicks = 0;
        flying = false;
        dirty = true;
        // vanishCooldown and dodgeCooldown intentionally survive normal state changes
    }
}
