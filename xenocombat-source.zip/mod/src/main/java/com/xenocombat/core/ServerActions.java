package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Server-side handler for every client request. The client only asks; every check (cooldowns, stun, range,
 * line of sight, feature toggles) is re-done here so a modified client cannot bypass the rules.
 */
public final class ServerActions {

    public static void handle(ServerPlayer p, Action action, int arg) {
        if (!p.isAlive() || p.isSpectator()) {
            return;
        }
        CombatState s = StateManager.of(p);
        boolean aerialBlocked = s.flying && !XenoConfig.ENABLE_AERIAL.get();

        switch (action) {
            case M1 -> {
                if (aerialBlocked) return;
                LivingEntity locked = validLock(p, s);
                ComboManager.tryM1(p, locked);
            }
            case GUARD_ON -> {
                if (!aerialBlocked) Guard.raise(p, s);
            }
            case GUARD_OFF -> Guard.lower(p, s);
            case DODGE -> {
                if (aerialBlocked) return;
                Vec3 dir = Dodge.direction(p, Dodge.forwardOf(arg), Dodge.strafeOf(arg), s.flying);
                Dodge.start(p, s, dir);
            }
            case VANISH -> {
                if (aerialBlocked) return;
                Vanish.tryVanish(p, s, validLock(p, s));
            }
            case LOCK -> handleLock(p, s, arg);
            case FLIGHT_TOGGLE -> Flight.toggle(p, s);
        }
    }

    private static void handleLock(ServerPlayer p, CombatState s, int id) {
        if (!XenoConfig.ENABLE_LOCK_ON.get()) {
            return;
        }
        if (id < 0) {
            clearLock(s);
            return;
        }
        LivingEntity t = Targeting.byId(p.level(), id);
        double range = XenoConfig.LOCK_ON_RANGE.get();
        if (t == null || !Targeting.isValidTarget(p, t) || p.distanceToSqr(t) > range * range
                || (XenoConfig.LOCK_ON_LOS.get() && !p.hasLineOfSight(t))) {
            return; // request rejected; client keeps its old state until the next sync
        }
        s.lockTargetId = t.getId();
        s.dirty = true;
    }

    /** The player's lock target if it is still valid and in range, otherwise clears the lock and returns null. */
    public static LivingEntity validLock(ServerPlayer p, CombatState s) {
        if (s.lockTargetId < 0) {
            return null;
        }
        LivingEntity t = Targeting.byId(p.level(), s.lockTargetId);
        double range = XenoConfig.LOCK_ON_RANGE.get() * 1.25; // small hysteresis so edge-of-range doesn't flicker
        if (t == null || !XenoConfig.ENABLE_LOCK_ON.get() || !Targeting.isValidTarget(p, t) || p.distanceToSqr(t) > range * range) {
            clearLock(s);
            return null;
        }
        return t;
    }

    private static void clearLock(CombatState s) {
        if (s.lockTargetId != -1) {
            s.lockTargetId = -1;
            s.dirty = true;
        }
    }

    private ServerActions() {}
}
