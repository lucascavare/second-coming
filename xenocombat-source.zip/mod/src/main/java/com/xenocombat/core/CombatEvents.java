package com.xenocombat.core;

import com.xenocombat.config.XenoConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Server-side Forge event hooks: tick driving, vanilla-damage integration, cleanup. */
public final class CombatEvents {

    // ------------------------------------------------------------------ ticking

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER || !(e.player instanceof ServerPlayer p)) {
            return;
        }
        CombatState s = StateManager.of(p);
        ServerActions.validLock(p, s);
        CombatTicker.tick(p, s);
        SyncManager.tick(p, s, p.level().getGameTime());
    }

    /** Ordinary mobs: only those currently tracked (they took part in combat) are ticked; idle ones are dropped. */
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        Iterator<Map.Entry<UUID, LivingEntity>> it = StateManager.trackedEntities();
        while (it.hasNext()) {
            Map.Entry<UUID, LivingEntity> entry = it.next();
            LivingEntity le = entry.getValue();
            if (le instanceof ServerPlayer) {
                continue; // players are ticked in onPlayerTick
            }
            CombatState s = StateManager.peek(le);
            if (s == null || le.isRemoved() || !le.isAlive()) {
                if (s != null) {
                    Stun.release(le, s);
                }
                it.remove();
                StateManager.removeState(entry.getKey());
                continue;
            }
            CombatTicker.tick(le, s);
            if (StateManager.isIdle(s)) {
                it.remove();
                StateManager.removeState(entry.getKey());
            }
        }
    }

    // ------------------------------------------------------------------ vanilla damage integration

    /**
     * Vanilla melee against a fighter that is dodging, vanishing or guarding. Our own M1 hits are resolved in
     * Hit.resolve and flagged with inCustomHit, so they never come through here.
     */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onAttacked(LivingAttackEvent e) {
        LivingEntity victim = e.getEntity();
        if (Hit.inCustomHit || victim.level().isClientSide) {
            return;
        }
        CombatState v = StateManager.peek(victim);
        if (v == null || !isMelee(e.getSource().getDirectEntity())) {
            return;
        }
        LivingEntity attacker = (LivingEntity) e.getSource().getDirectEntity();
        if (v.invuln > 0) {
            e.setCanceled(true); // dodge / vanish i-frames
            return;
        }
        if (v.guarding && Hit.isFrontal(victim, attacker) && Guard.inParryWindow(v)) {
            Hit.applyParry(attacker, victim, StateManager.of(attacker), v);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (Hit.inCustomHit || victim.level().isClientSide) {
            return;
        }
        CombatState v = StateManager.peek(victim);
        if (v == null || !v.guarding || !isMelee(e.getSource().getDirectEntity())) {
            return;
        }
        LivingEntity attacker = (LivingEntity) e.getSource().getDirectEntity();
        if (Hit.isFrontal(victim, attacker)) {
            e.setAmount(e.getAmount() * XenoConfig.GUARD_DAMAGE_MULTIPLIER.get().floatValue());
            Fx.guard(victim);
        }
    }

    @SubscribeEvent
    public void onKnockback(LivingKnockBackEvent e) {
        if (Hit.inCustomHit || e.getEntity().level().isClientSide) {
            return;
        }
        CombatState v = StateManager.peek(e.getEntity());
        if (v != null && v.guarding) {
            e.setStrength(e.getStrength() * 0.25f); // guarding holds your ground
        }
    }

    @SubscribeEvent
    public void onFall(LivingFallEvent e) {
        CombatState s = StateManager.peek(e.getEntity());
        if (s != null && (s.flying || s.hover > 0 || s.launched || s.dodgeTicks > 0 || s.hitstunImmunity > 0)) {
            e.setCanceled(true);
        }
    }

    private static boolean isMelee(Entity direct) {
        return direct instanceof LivingEntity && !(direct instanceof Projectile);
    }

    // ------------------------------------------------------------------ player-side rules

    /** The custom M1 replaces vanilla attacks completely; the client intercepts the click, this is the server backstop. */
    @SubscribeEvent
    public void onVanillaAttack(AttackEntityEvent e) {
        if (!e.getEntity().level().isClientSide) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onUseItem(LivingEntityUseItemEvent.Start e) {
        if (e.getEntity().level().isClientSide) {
            return;
        }
        CombatState s = StateManager.peek(e.getEntity());
        if (s != null && s.isStunned()) {
            e.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ lifecycle / cleanup

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (dead.level().isClientSide) {
            return;
        }
        CombatState s = StateManager.peek(dead);
        if (s != null) {
            Flight.revokeMayfly(dead, s);
            Stun.release(dead, s);
            s.clearForDeath();
            dead.setNoGravity(false);
            if (!(dead instanceof ICombatant) && !(dead instanceof ServerPlayer)) {
                StateManager.remove(dead);
            }
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            CombatState s = StateManager.peek(p);
            if (s != null) {
                Flight.stop(p, s);
                Flight.revokeMayfly(p, s);
                StateManager.remove(p);
            }
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            Flight.cleanStaleMayfly(p); // crash-safety: mayfly we granted but never got to revoke
            SyncManager.invalidate(StateManager.of(p));
        }
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            CombatState s = StateManager.of(p);
            s.clearForDeath();
            s.vanishCooldown = 0; // a new life starts with fresh cooldowns
            s.dodgeCooldown = 0;
            SyncManager.invalidate(s);
        }
    }

    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            SyncManager.invalidate(StateManager.of(p));
        }
    }

    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent e) {
        StateManager.clearAll();
    }
}
