package com.xenocombat.core;

/** Implemented by entities that own their CombatState directly (the combat NPC). Everyone else uses StateManager's map. */
public interface ICombatant {
    CombatState combatState();

    /** Base damage of this fighter's M1 hits 1-4 (the finisher multiplier is applied on top). */
    float m1Damage();
}
