package com.xenocombat.core;

import net.minecraft.world.entity.LivingEntity;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns CombatState for players and ordinary mobs (keyed by UUID). Entries are created lazily the first
 * time a fighter takes part in combat and removed when the entity leaves the level / logs out.
 * Only entries that are "active" (non-idle) are ticked, so thousands of untouched mobs cost nothing.
 */
public final class StateManager {
    private static final Map<UUID, CombatState> STATES = new ConcurrentHashMap<>();
    private static final Map<UUID, LivingEntity> ENTITIES = new ConcurrentHashMap<>();

    public static CombatState of(LivingEntity e) {
        if (e instanceof ICombatant c) {
            return c.combatState();
        }
        ENTITIES.put(e.getUUID(), e);
        return STATES.computeIfAbsent(e.getUUID(), id -> new CombatState());
    }

    /** Returns the state only if one already exists (never allocates). */
    public static CombatState peek(LivingEntity e) {
        if (e instanceof ICombatant c) {
            return c.combatState();
        }
        return STATES.get(e.getUUID());
    }

    public static void remove(LivingEntity e) {
        removeState(e.getUUID());
    }

    public static void removeState(UUID id) {
        STATES.remove(id);
        ENTITIES.remove(id);
    }

    /** Iterate tracked non-NPC fighters. Callers may remove through the iterator. */
    public static Iterator<Map.Entry<UUID, LivingEntity>> trackedEntities() {
        return ENTITIES.entrySet().iterator();
    }

    public static void clearAll() {
        STATES.clear();
        ENTITIES.clear();
    }

    public static boolean isIdle(CombatState s) {
        return s.combo == 0 && s.comboTimer == 0 && s.attackCooldown == 0 && s.hitstun == 0 && s.punish == 0
                && !s.launched && s.hitstunImmunity == 0 && !s.guarding && s.guardLock == 0 && s.invuln == 0
                && s.dodgeCooldown == 0 && s.dodgeTicks == 0 && s.vanishCooldown == 0 && s.lungeTicks == 0
                && s.pursuitTicks == 0 && s.lockTargetId == -1 && !s.flying && s.sinceHit >= 100
                && s.hover == 0 && !s.frozen;
    }

    private StateManager() {}
}
