# Xeno Combat — Xenoverse-style melee for Minecraft 1.20.1

Target: **Minecraft Java 1.20.1 · Forge 47.4.10 · Java 17**. Single standalone jar, **no dependencies**.

> ## ⚠ STATUS: SOURCE COMPLETE, NOT YET COMPILED OR PLAYTESTED
> This source was written in a sandbox that could not reach `maven.minecraftforge.net`, Maven Central or Mojang's
> servers (the network policy returned 403), so the Forge toolchain could not be downloaded. **Nothing here has been
> compiled against Minecraft or run in the game.** What *was* verified: Java syntax of all 43 source files (`javac`
> parse check), and that every config option / combat-state field / cross-class call referenced in the code exists.
> What could not be verified: that every Minecraft/Forge API call matches 1.20.1 exactly, and that any mechanic
> actually plays correctly. Expect a first round of compile errors and tuning. See **"First build & test"** below.

## Build (once, on your machine)
1. Install a JDK 17 (the project's Gradle setup will also auto-download one if missing).
2. In this folder run `./gradlew build` (Windows: `gradlew.bat build`).
3. The jar is `build/libs/xenocombat-1.0.0.jar`.
4. To test in a dev client: `./gradlew runClient` (dedicated server: `./gradlew runServer`).

## Install (players)
1. Install Minecraft Java 1.20.1, then Forge 47.4.10; launch once.
2. Copy `xenocombat-1.0.0.jar` into `.minecraft/mods`.
3. Launch with the Forge profile. On a server, the same jar goes in the server's `mods` folder (and on every client).

**Dependencies:** none.

## Controls (Options → Controls → Key Binds → "Xeno Combat")
| Action | Default | Notes |
|---|---|---|
| **M1** | Left mouse (vanilla Attack) | Replaces vanilla melee. Hold to chain. Mining a block you're aiming at (while not locked on / flying) is still vanilla. |
| Lock-On | `R` | Tap to lock the target nearest your crosshair; tap again to release; **Sneak + tap** switches target. |
| Guard | `G` (hold) | Raise it *just before* a hit lands for a **Perfect Parry**. Holding it permanently only gives normal guard. |
| Z-Vanish | `Z` | 7 s cooldown. While stunned = escape; otherwise = teleport next to your launched/locked target. |
| Dodge | `V` | Hold a movement direction (none = backward). Works in the air. |
| Flight toggle | `H` | Survival/adventure only. Landing ends flight. |
| Fly forward/back/left/right | `W/S/A/D` | Only active while flying. |
| Fly ascend / descend / boost | `Space` / `Left Ctrl` / `Left Shift` | Only active while flying. |

The fly keys share their default keys with walking, so the Controls screen shows them as "conflicting". That is
intentional — they only apply while flying — and all of them are rebindable.

## The combat loop
- **M1 ×5:** hits 1–4 deal `m1Damage` and put the target in hitstun; **hit 5** deals ×`finisherDamageMultiplier` and **launches** the target. The chain resets if you wait longer than `comboWindowTicks`, whiff, are dodged, or are hit.
- **Lunge:** M1 with nobody in reach but a locked target within `lungeRange` rushes the target and swings on arrival (stops at walls, works in the air).
- **Z-Vanish pursuit:** after a launch you have a 3-second pursuit window: press Z to appear behind/beside the launched target and keep comboing.
- **Defensive Z-Vanish:** while stunned (or within `activationWindowTicks` of a hit) Z breaks the stun and puts you behind the attacker with a brief invulnerability.
- **Anti stun-lock:** stun can't exceed 5 s continuously, and a victim is immune to new hitstun for `hitstunImmunityTicks` after a stun ends.
- **Flight:** not creative flight. Gravity/fall damage are off while flying, you're stunned and fall like anyone else when hit, and all combat actions keep working.
- No ki, transformations, stamina or energy bars exist. The only HUD is text (lock target, combo count, Z-Vanish ready/cooldown, state).

## Combat NPC: "Xeno Fighter"
- **Spawn:** creative inventory → Spawn Eggs → *Xeno Fighter Spawn Egg*, or `/summon xenocombat:combat_npc`, or `/give @s xenocombat:combat_npc_spawn_egg`.
- **Natural spawning:** off by default. Set `npc.naturalSpawning = true` (very rare, overworld).
- A label above its head shows its current combat state (Idle, Searching, Targeting, Approaching, Combat, Attacking, Combo, Hitstun, Blocking, Parrying, Dodging, Knocked Back, Pursuing, Vanishing, Flying, Aerial Combat, Recovering, Retreating).
- It runs a state machine (`ai/CombatBrain`) on top of the *same* combat code the player uses: the same 5-hit chain, hitstun, guard, parry window, dodge, Z-Vanish manager (same 7 s cooldown) and flight state.
- **It does not cheat:** it only perceives what an onlooker could see (line of sight, visible guard/flight/swing/stun, a vanish puff), never your cooldowns, combo count or inputs; it reacts after a delay; its chances are capped below certainty; continuous flight is limited; it cannot teleport through walls; target search is one bounded query every ~10 ticks.
- **Difficulty** (`npc.difficulty`): EASY / NORMAL / HARD change reaction delay (14 / 8 / 4 ticks), parry/dodge/guard/vanish chances, aggression, aim-tracking speed and flight endurance. `parryChanceScale`, `dodgeChanceScale`, `vanishChanceScale`, `reactionTicksOverride` fine-tune it.

## Configuration
- **In game:** Mods → Xeno Combat → **Config**. Every option is listed (hover for a description); booleans/enums click to cycle; Done validates and saves.
- **Dedicated server:** edit `config/xenocombat-common.toml`, or as an operator use `/xenocombat list`, `/xenocombat get <option>`, `/xenocombat set <option> <value>` (e.g. `/xenocombat set vanish.cooldownTicks 140`).
- Files: `config/xenocombat-common.toml` (all combat/AI/flight/targeting; the **server's** copy governs on servers) and `config/xenocombat-client.toml` (camera only).
- Ticks: 20 per second. Z-Vanish cooldown = `vanish.cooldownTicks` (default 140 = 7 s).

## Technical notes / known limitations
- **Not compiled/tested yet** (see top).
- **Camera distance:** vanilla 1.20.1 exposes no hook for third-person camera distance, so there is no "combat camera distance" option. Lock-on aiming, smoothing and an optional switch to third person (`camera.forceThirdPersonOnLock`) are provided instead.
- **Movement authority:** vanilla player positions are client-authoritative. Z-Vanish and all combat results are server-decided (and teleport is server-side), but flight steering is computed on the client from your fly keys; the server owns whether you are flying, gravity, fall damage and the cooldowns. No extra speed-hack detection beyond vanilla's.
- **Hitstun on players** is enforced by the server rejecting every action while stunned, plus the client zeroing movement input; the server cannot literally freeze a player's own movement.
- **Hitstun on other mobs** works by disabling their move/look/jump goals. Brain-based mobs (piglins, villagers, allays…) are only partly held.
- **Peaceful difficulty:** mob-attack damage is scaled to 0 by vanilla, so the NPC will still launch/stun you but not hurt you.
- Parry timing is evaluated server-side from when your guard packet is processed, so high latency shifts the window slightly in the server's favor or against you by your ping.

## First build & test (please do this and send me the results)
Run `./gradlew build` and send me **every compile error** verbatim; I'll fix them. Then in a creative world (switch to survival to test flight):
1. Spawn a Xeno Fighter. Lock on (`R`), click M1 five times: expect 4 hitstunned hits then a launch.
2. Right after the launch press `Z`: you should appear next to it; note the 7 s cooldown on the HUD.
3. Let the NPC hit you: raise guard (`G`) just before a hit for a parry spark; dodge with `V`; press `Z` while stunned to escape.
4. Press `H` and fly (W/Space/Shift); the NPC should fly after you; fight in the air.
5. If anything crashes, send `logs/latest.log` and `crash-reports/*.txt`.
